<?php

// Require widget files
require plugin_dir_path(__FILE__) . 'Coro_widget_recent_post.php';
require plugin_dir_path(__FILE__) . 'Coro_widget_recent_comments.php';


// Register Widgets
add_action( 'widgets_init', function() {
    register_widget( 'Coro_widget_recent_post');
    register_widget( 'Coro_widget_recent_comments');
});
