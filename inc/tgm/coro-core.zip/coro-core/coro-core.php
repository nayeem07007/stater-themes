<?php
/**
 * Plugin Name: Coro Core
 * Plugin URI: https://themeforest.net/user/droitthemes/portfolio
 * Description: This plugin adds the core features to the Coro WordPress theme. You must have to install this plugin to get all the features included with the Coro theme.
 * Version: 0.0.9
 * Author: DroitThemes
 * Author URI: https://themeforest.net/user/droitthemes/portfolio
 * Text domain: coro-core
 */

if ( !defined( 'ABSPATH') )
    die( '-1');

// Coro Core Directories
define( 'SC_IMAGES', plugins_url( 'widgets/images/', __FILE__));

// Make sure the same class is not loaded twice in free/premium versions.
if ( !class_exists( 'Coro_core' ) ) {
	/**
	 * Main Coro Core Class
	 *
	 * The main class that initiates and runs the Coro Core plugin.
	 *
	 * @since 1.7.0
	 */
	class Coro_core {
		/**
		 * Coro Core Version
		 *
		 * Holds the version of the plugin.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 Moved from property with that name to a constant.
		 *
		 * @var string The plugin version.
		 */
		const VERSION = '1.0' ;
		/**
		 * Minimum Elementor Version
		 *
		 * Holds the minimum Elementor version required to run the plugin.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 Moved from property with that name to a constant.
		 *
		 * @var string Minimum Elementor version required to run the plugin.
		 */
		const MINIMUM_ELEMENTOR_VERSION = '2.6.0';
		/**
		 * Minimum PHP Version
		 *
		 * Holds the minimum PHP version required to run the plugin.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 Moved from property with that name to a constant.
		 *
		 * @var string Minimum PHP version required to run the plugin.
		 */
		const  MINIMUM_PHP_VERSION = '5.4' ;
        /**
         * Plugin's directory paths
         * @since 1.0
         */
        const CSS = null;
        const JS = null;
        const IMG = null;
        const VEND = null;

		/**
		 * Instance
		 *
		 * Holds a single instance of the `Coro_Core` class.
		 *
		 * @since 1.7.0
		 *
		 * @access private
		 * @static
		 *
		 * @var Coro_Core A single instance of the class.
		 */
		private static  $_instance = null ;
		/**
		 * Instance
		 *
		 * Ensures only one instance of the class is loaded or can be loaded.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 * @static
		 *
		 * @return Coro_Core An instance of the class.
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}

		/**
		 * Clone
		 *
		 * Disable class cloning.
		 *
		 * @since 1.7.0
		 *
		 * @access protected
		 *
		 * @return void
		 */
		public function __clone() {
			// Cloning instances of the class is forbidden
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'coro-core' ), '1.7.0' );
		}

		/**
		 * Wakeup
		 *
		 * Disable unserializing the class.
		 *
		 * @since 1.7.0
		 *
		 * @access protected
		 *
		 * @return void
		 */
		public function __wakeup() {
			// Unserializing instances of the class is forbidden.
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'coro-core' ), '1.7.0' );
		}

		/**
		 * Constructor
		 *
		 * Initialize the Coro Core plugins.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 */
		public function __construct() {
			$this->init_hooks();
			$this->core_includes();
			do_action( 'coro_core_loaded' );
		}

		/**
		 * Include Files
		 *
		 * Load core files required to run the plugin.
		 *
		 * @access public
		 */
		public function core_includes() {
			// Extra functions
			require_once __DIR__ . '/inc/extra.php';

            require_once __DIR__ . '/post-type/footer.pt.php';

            /**
             * Register widget area.
             *
             * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
             */
			require_once __DIR__ . '/wp-widgets/widgets.php';

			// Elementor custom field icons
			require_once __DIR__ . '/fields/icons.php';

            // RGBA color picker
            require plugin_dir_path(__FILE__) . '/acf-rgba-color-picker/acf-rgba-color-picker.php';

            // ACF Metaboxes
            require plugin_dir_path(__FILE__) . '/inc/metaboxes.php';
            require plugin_dir_path(__FILE__) . '/inc/mega-menu.php';
		}

		/**
		 * Init Hooks
		 *
		 * Hook into actions and filters.
		 *
		 * @access private
		 */
		private function init_hooks() {
			add_action( 'init', [ $this, 'i18n' ] );
			add_action( 'plugins_loaded', [ $this, 'init' ] );
		}

		/**
		 * Load Textdomain
		 *
		 * Load plugin localization files.
		 *
		 * @access public
		 */
		public function i18n() {
			load_plugin_textdomain( 'coro-core', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
		}


		/**
		 * Init Coro Core
		 *
		 * Load the plugin after Elementor (and other plugins) are loaded.
		 *
		 * @access public
		 */
		public function init() {

			if ( !did_action( 'elementor/loaded' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
				return;
			}

			// Check for required Elementor version

			if ( !version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
				return;
			}

			// Check for required PHP version

			if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
				return;
			}

			// Add new Elementor Categories
			add_action( 'elementor/init', [ $this, 'add_elementor_category' ] );

			// Register Widget Scripts
			add_action( 'elementor/frontend/after_register_scripts', [ $this, 'register_widget_scripts' ] );
			add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'register_widget_scripts' ] );
            add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );

			// Register Widget Scripts
            add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'enqueue_elementor_editor_styles' ] );
			add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'enqueue_widget_styles' ] );

			// Register New Widgets
			add_action( 'elementor/widgets/widgets_registered', [ $this, 'on_widgets_registered' ] );
		}


		/**
		 * Admin notice
		 *
		 * Warning when the site doesn't have Elementor installed or activated.
		 *
		 * @since 1.1.0
		 * @since 1.7.0 Moved from a standalone function to a class method.
		 *
		 * @access public
		 */
		public function admin_notice_missing_main_plugin() {
			$message = sprintf(
			/* translators: 1: Coro Core 2: Elementor */
				esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'coro-core' ),
				'<strong>' . esc_html__( 'Coro core', 'coro-core' ) . '</strong>',
				'<strong>' . esc_html__( 'Elementor', 'coro-core' ) . '</strong>'
			);
			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
		}

		/**
		 * Admin notice
		 *
		 * Warning when the site doesn't have a minimum required Elementor version.
		 *
		 * @since 1.1.0
		 * @since 1.7.0 Moved from a standalone function to a class method.
		 *
		 * @access public
		 */
		public function admin_notice_minimum_elementor_version() {
			$message = sprintf(
			/* translators: 1: Coro Core 2: Elementor 3: Required Elementor version */
				esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'coro-core' ),
				'<strong>' . esc_html__( 'Coro Core', 'coro-core' ) . '</strong>',
				'<strong>' . esc_html__( 'Elementor', 'coro-core' ) . '</strong>',
				self::MINIMUM_ELEMENTOR_VERSION
			);
			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
		}

		/**
		 * Admin notice
		 *
		 * Warning when the site doesn't have a minimum required PHP version.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 */
		public function admin_notice_minimum_php_version() {
			$message = sprintf(
			/* translators: 1: Coro Core 2: PHP 3: Required PHP version */
				esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'coro-core' ),
				'<strong>' . esc_html__( 'Coro Core', 'coro-core' ) . '</strong>',
				'<strong>' . esc_html__( 'PHP', 'coro-core' ) . '</strong>',
				self::MINIMUM_PHP_VERSION
			);
			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
		}

		/**
		 * Add new Elementor Categories
		 *
		 * Register new widget categories for Coro Core widgets.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access public
		 */
		public function add_elementor_category() {
			\Elementor\Plugin::instance()->elements_manager->add_category( 'coro-elements', [
				'title' => __( 'Coro Elements', 'coro-core' ),
			], 1 );
		}

		/**
		 * Register Widget Scripts
		 *
		 * Register custom scripts required to run Coro Core.
		 *
		 * @since 1.6.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access public
		 */
		public function register_widget_scripts() {

            wp_register_script( 'coro-comming-soon', plugins_url('assets/js/comming-soon.js', __FILE__), array('jquery'), '1.0.0', true );

            wp_register_script( 'slick', plugins_url('assets/vendors/slick/slick.min.js', __FILE__), array('jquery'), '1.8.1', true );

            wp_register_script( 'owl-carousel', plugins_url('assets/vendors/owl-carousel/owl.carousel.min.js', __FILE__), array('jquery'), '2.3.4', true );

            wp_register_script( 'isotope', plugins_url('assets/vendors/isotope/isotope-min.js', __FILE__), array('jquery'), '3.0.1', true );

            wp_register_script( 'imagesloaded', plugins_url('assets/vendors/imagesloaded/imagesloaded.pkgd.min.js', __FILE__), array('jquery'), '4.1.0', true );

            wp_register_script( 'swiper', plugins_url('assets/vendors/swipper/js/swiper.min.js', __FILE__), array('jquery'), '4.4.6', true );

            wp_register_script( 'magnify-popup', plugins_url('assets/vendors/magnify-popup/jquery.magnific-popup.min.js', __FILE__), array('jquery'), '1.1.0', true );

            wp_register_script( 'instagramFeed', plugins_url('assets/js/jquery.instagramFeed.min.js', __FILE__), array('jquery'), '1.0', true );

            wp_register_script( 'ajax-chimp', plugins_url('assets/js/ajax-chimp.js', __FILE__), array('jquery'), '1.0', true );
		}

		/**
		 * Register Widget Styles
		 *
		 * Register custom styles required to run Coro Core.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access public
		 */
		
		public function enqueue_widget_styles() {
            wp_register_style( 'slick', plugins_url( 'assets/vendors/slick/slick.css', __FILE__ ) );
            wp_register_style( 'slick-theme', plugins_url( 'assets/vendors/slick/slick-theme.css', __FILE__ ) );
            wp_register_style( 'owl-carousel', plugins_url( 'assets/vendors/owl-carousel/assets/owl.carousel.css', __FILE__ ) );
            wp_register_style( 'swiper', plugins_url( 'assets/vendors/swipper/css/swiper.min.css', __FILE__ ) );
            wp_register_style( 'swiper', plugins_url( 'assets/vendors/swipper/css/swiper.min.css', __FILE__ ) );
            wp_register_style( 'elegant-icon', plugins_url( 'assets/vendors/elagent-icon/style.css', __FILE__ ) );
            wp_register_style( 'magnify-popup', plugins_url( 'assets/vendors/magnify-popup/magnific-popup.css', __FILE__ ) );
		}

		public function enqueue_elementor_editor_styles() {
            wp_enqueue_style( 'simple-line-icon', plugins_url( 'assets/vendors/simple-line-icon/simple-line-icons.css', __FILE__ ) );
            wp_enqueue_style( 'themfiy-icons', plugins_url( 'assets/vendors/themfiy/themify-icons.css', __FILE__ ) );
            wp_enqueue_style( 'coro-elementor-editor', plugins_url( 'assets/css/coro-elementor-editor.css', __FILE__ ) );
		}

        public function enqueue_scripts() {
		    // WooCommerce File dependencies

        }


		/*public function register_admin_styles() {
            wp_enqueue_style( 'coro_core_admin', plugins_url( 'assets/css/coro-core-admin.css', __FILE__ ) );
        }*/

		/**
		 * Register New Widgets
		 *
		 * Include Coro Core widgets files and register them in Elementor.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access public
		 */
		public function on_widgets_registered() {
			$this->include_widgets();
			$this->register_widgets();
		}

		/**
		 * Include Widgets Files
		 *
		 * Load Coro Core widgets files.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access private
		 */
		private function include_widgets() {
			require_once __DIR__ . '/widgets/slider/Coro_slider.php';

			require_once __DIR__ . '/widgets/product-categories/Coro_product_categories.php';

			require_once __DIR__ . '/widgets/products/Coro_products.php';

			require_once __DIR__ . '/widgets/testimonials/Coro_testimonials.php';

			require_once __DIR__ . '/widgets/subscribe-form/Coro_subscribe_form.php';

			require_once __DIR__ . '/widgets/blog/Coro_blog.php';

			require_once __DIR__ . '/widgets/count-down/Coro_count_down.php';

			require_once __DIR__ . '/widgets/icons/Coro_icons.php';

			require_once __DIR__ . '/widgets/single-video/Coro_single_video.php';

			require_once __DIR__ . '/widgets/instagram-feeds/Coro_instagram.php';

			require_once __DIR__ . '/widgets/faqs/Coro_faqs.php';

			require_once __DIR__ . '/widgets/product-banner/Coro_product_banner.php';
        }

		/**
		 * Register Widgets
		 *
		 * Register Coro Core widgets.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access private
		 */
		private function register_widgets() {
			// Site Elements
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CoroCore\Widgets\Coro_slider() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CoroCore\Widgets\Coro_product_categories() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CoroCore\Widgets\Coro_products() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CoroCore\Widgets\Coro_testimonials() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CoroCore\Widgets\Coro_subscribe_form() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CoroCore\Widgets\Coro_blog() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CoroCore\Widgets\Coro_count_down() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CoroCore\Widgets\Coro_icons() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CoroCore\Widgets\Coro_single_video() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CoroCore\Widgets\Coro_instagram() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CoroCore\Widgets\Coro_faqs() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CoroCore\Widgets\Coro_product_banner() );
        }
	}
}
// Make sure the same function is not loaded twice in free/premium versions.

if ( !function_exists( 'coro_core_load' ) ) {
	/**
	 * Load Coro Core
	 *
	 * Main instance of Coro_Core.
	 *
	 * @since 1.0.0
	 * @since 1.7.0 The logic moved from this function to a class method.
	 */
	function coro_core_load() {
		return Coro_core::instance();
	}

	// Run Coro Core
    coro_core_load();
}


function coro_admin_cpt_script( $hook ) {

    global $post;

    if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
        if ( 'service' === $post->post_type ) {
            wp_enqueue_style( 'themify-icons', plugins_url( 'assets/vendors/themify-icon/themify-icons.css', __FILE__ ));
        }
    }
}
add_action( 'admin_enqueue_scripts', 'coro_admin_cpt_script', 10, 1 );