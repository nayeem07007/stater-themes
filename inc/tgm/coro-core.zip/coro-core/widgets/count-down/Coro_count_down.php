<?php
namespace CoroCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;



// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Coro_count_down
 * @package CoroCore\Widgets
 */
class Coro_count_down extends Widget_Base {

    public function get_name() {
        return 'coro_count_down';
    }

    public function get_title() {
        return __( 'Coro Countdown', 'coro-core' );
    }

    public function get_icon() {
        return 'eicon-countdown';
    }

    public function get_categories() {
        return [ 'coro-elements' ];
    }

    public function get_script_depends() {
        return [ 'coro-comming-soon' ];
    }


    protected function _register_controls() {

        // ------------------------------------------------- Count Down -------------------------------------------//
        $this->start_controls_section(
            'date_count_down_sec', [
                'label' => __( 'Contents', 'coro-core' ),
            ]
        );

        $this->add_control(
            'date_count_down',
            [
                'label' => __( 'Date Time Picker', 'coro-core' ),
                'type' => \Elementor\Controls_Manager::DATE_TIME,
                'picker_options' => array(
                    'dateFormat' => "Y-m-d",
                )
            ]
        );

        $this->end_controls_section();


        //----------------------------------------- Date Picker Style ----------------------------------------------------//
        $this->start_controls_section(
            'date_picker_style', [
                'label' => __( 'Date Picker', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'color_date_picker', [
                'label' => __( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pr_comedown_info .clock .timer span' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'typo_date_picker',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '
                    {{WRAPPER}} .pr_comedown_info .clock .timer span',
            ]
        );

        $this->end_controls_section();


        //----------------------------------------- Date Picker Text Style ----------------------------------------------------//
        $this->start_controls_section(
            'date_picker_text_style', [
                'label' => __( 'Date Picker Text', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'color_date_picker_text', [
                'label' => __( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pr_comedown_info .clock .smalltext' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'color_date_picker_divider', [
                'label' => __( 'Divider Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pr_comedown_info .clock .timer span:before' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'typo_date_picker_text',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '
                    {{WRAPPER}} .pr_comedown_info .clock .smalltext',
            ]
        );

        $this->end_controls_section();


        //----------------------------------------- Section Background Style ----------------------------------------------------//
        $this->start_controls_section(
            'sec_bg_style', [
                'label' => __( 'Section Background', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'sec_padding', [
                'label' => esc_html__( 'Padding', 'coro-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .pr_comedown_info .clock' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'unit' => 'px', // The selected CSS Unit. 'px', '%', 'em',

                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {


        $settings = $this->get_settings_for_display();
        $date_count_down = !empty( $settings['date_count_down'] ) ? $settings['date_count_down'] : '';
        ?>
        <div class="pr_comedown_info text-center">
            <?php
            if ( $date_count_down ) {
                echo '<div id="clockdiv" class="clock" data-date="'. esc_attr($date_count_down) .'"></div>';
            } ?>
        </div>
        <?php
    }
}