<?php
namespace CoroCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use WP_Query;



// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}



/**
 * Text Typing Effect
 *
 * Elementor widget for text typing effect.
 *
 * @since 1.7.0
 */
class Coro_instagram extends Widget_Base {

    public function get_name() {
        return 'coro_instagram';
    }

    public function get_title() {
        return __( 'Instagram-Feeds', 'coro-core' );
    }

    public function get_icon() {
        return 'fa fa-instagram';
    }

    public function get_categories() {
        return [ 'coro-elements' ];
    }

    public function get_script_depends() {
        return [ 'instagramFeed' ];
    }

    protected function _register_controls() {


        $this->start_controls_section(
            'coro_instagram_block', [
                'label' => __( 'Instagram - Feeds', 'coro-core' ),
            ]
        );

        $this->add_control(
            'user_name', [
                'label' => esc_html__( 'User Name', 'coro-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default'   => 'droitlab'
            ]
        );

        $this->add_control(
            'show_number', [
                'label' => __( 'Show Number', 'coro-core' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 100,
                'step' => 1,
                'default' => 5,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'item_box_color_sec', [
                'label' => __( 'Item Box Color', 'coro-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'item_box_color', [
                'label' => __( 'Hover Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .instragram_area .item .hover_icon' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings();
        $user_name = !empty( $settings['user_name'] ) ? $settings['user_name'] : '';
        $items     = !empty( $settings['show_number'] ) ? $settings['show_number'] : '';
        ?>
        <section class="instragram_area" data-username="<?php echo esc_attr( $user_name ); ?>" data-items="<?php echo esc_attr( $items ); ?>">
        </section>
        <?php
        if( $user_name ) {
            echo '<div class="coro_instagram_feeds"><a href="https://www.instagram.com/'.esc_html( $user_name ).'" class="btn_instragram" target="_blank">@'. esc_html( $user_name ) .'</a></div>';
        } ?>

        <script>
            ;(function($){
                "use strict";
                $(document).ready(function () {

                    function cp_instagram_photos() {
                        $('.instragram_area').each(function(){
                            $.instagramFeed({
                                'username': $(this).data('username'),
                                'container': $(this),
                                'display_profile': false,
                                'display_biography': false,
                                'items': $(this).data('items'),
                                'margin': 0
                            });
                            console.log( $(this) );
                        });

                    }
                    cp_instagram_photos();

                });
            })(jQuery);

        </script>
        <?php
    }

}