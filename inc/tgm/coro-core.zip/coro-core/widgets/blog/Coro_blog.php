<?php
namespace CoroCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use WP_Query;



// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Text Typing Effect
 *
 * Elementor widget for text typing effect.
 *
 * @since 1.7.0
 */
class Coro_blog extends Widget_Base {

    public function get_name() {
        return 'coro_blog';
    }

    public function get_title() {
        return __( 'Blog Posts', 'coro-core' );
    }

    public function get_icon() {
        return ' eicon-post';
    }

    public function get_categories() {
        return [ 'coro-elements' ];
    }

    protected function _register_controls() {


        // ---------------------------------- Filter Options ------------------------
        $this->start_controls_section(
            'filter', [
                'label' => __( 'Filter', 'coro-core' ),
            ]
        );

        $this->add_control(
            'show_count', [
                'label' => esc_html__( 'Show Posts Count', 'coro-core' ),
                'type' => Controls_Manager::NUMBER,
                'default' => 4
            ]
        );

        $this->add_control(
            'order', [
                'label' => esc_html__( 'Order', 'coro-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'ASC' => 'ASC',
                    'DESC' => 'DESC'
                ],
                'default' => 'ASC'
            ]
        );

        $this->add_control(
            'btn_title', [
                'label' => __( 'Read More Button', 'coro-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Read More'
            ]
        );

        $this->end_controls_section();


        // -------------------------------------- Column Grid Section ---------------------------------//
        $this->start_controls_section(
            'column_sec', [
                'label' => __( 'Grid Column', 'coro-core' ),
            ]
        );

        $this->add_control(
            'column', [
                'label' => __( 'Grid Column', 'coro-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '6' => __( 'Two column', 'coro-core' ),
                    '4' => __( 'Three column', 'coro-core' ),
                    '3' => __( 'Four column', 'coro-core' ),
                ],
                'default' => '6'
            ]
        );

        $this->end_controls_section();


        // -------------------------------------- Accent Color  ---------------------------------//
        $this->start_controls_section(
            'accent_color_sec', [
                'label' => __( 'Accent Color', 'coro-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        //---------------------------- Normal and Hover ---------------------------//
        $this->start_controls_tabs(
            'accent_style_tabs'

        );

        /************************** Normal Color *****************************/
        $this->start_controls_tab(
            'accent_normal',
            [
                'label' => __( 'Normal', 'coro-core' ),
            ]
        );

        $this->add_control(
            'accent_normal_font_color', [
                'label' => __( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .h_blog_item .categori_tag, {{WRAPPER}} .h_blog_item h3, {{WRAPPER}} .h_blog_item .read_btn' => 'border-color: {{VALUE}}; color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        //**************************** Hover Color *****************************//
        $this->start_controls_tab(
            'accent_hover_style',
            [
                'label' => __( 'Hover', 'coro-core' ),
            ]
        );

        $this->add_control(
            'accent_hover_font_color', [
                'label' => __( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .h_blog_item .categori_tag:hover, {{WRAPPER}} .h_blog_item h3:hover, {{WRAPPER}} .h_blog_item .read_btn:hover' => 'border-color: {{VALUE}}; color: {{VALUE}};',
                ]
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->end_controls_section();

        // -------------------------------------- Column Grid Section ---------------------------------//
        $this->start_controls_section(
            'sec_bg_style', [
                'label' => __( 'Style Background', 'coro-core' ),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_control(
            'sec_bg_color', [
                'label' => __( 'Background Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .h_blog_area' => 'background: {{VALUE}}',
                ]
            ]
        );

        $this->add_control(
            'padding',
            [
                'label' => __( 'Padding', 'coro-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .h_blog_area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings();
        $blog_post = new WP_Query(array(
            'post_type'     => 'post',
            'posts_per_page' => $settings['show_count'],
            'order' => $settings['order'],
        ));
        ?>
        <section class="h_blog_area">
            <div class="container-fluid">
                <div class="row h_blog_info m10">
                    <?php
                    while ( $blog_post->have_posts() ) : $blog_post->the_post();
                        ?>
                        <div class="col-lg-<?php echo esc_attr( $settings['column'] ) ?> col-md-6 h_blog_item p10">
                            <?php
                            the_post_thumbnail( 'coro_560x328' );
                            coro_taxonomy_terms();
                            ?>
                            <a href="<?php the_permalink() ?>">
                                <h3><?php the_title() ?></h3>
                            </a>
                            <?php
                            if ( !empty( $settings['btn_title'] ) ) { ?>
                                <a href="<?php the_permalink() ?>" class="read_btn"><?php echo esc_html( $settings['btn_title'] ) ?></a>
                                <?php
                            }
                            ?>
                        </div>
                        <?php
                    endwhile;
                    wp_reset_postdata();
                    ?>
                </div>
            </div>
        </section>
        <?php
    }
}