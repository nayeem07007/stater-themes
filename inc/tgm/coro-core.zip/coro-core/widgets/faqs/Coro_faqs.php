<?php
namespace CoroCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;



// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}



/**
 * Text Typing Effect
 *
 * Elementor widget for text typing effect.
 *
 * @since 1.7.0
 */
class Coro_faqs extends Widget_Base {

    public function get_name() {
        return 'coro_faqs';
    }

    public function get_title() {
        return __( 'FAQs', 'coro-core' );
    }

    public function get_icon() {
        return ' eicon-countdown';
    }

    public function get_categories() {
        return [ 'coro-elements' ];
    }

    public function get_script_depends() {
        return [ 'comming-soon' ];
    }


    protected function _register_controls() {

        $this->start_controls_section(
            'tabs_sec',
            [
                'label' => __( 'FAQs', 'wavee-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'tab_title', [
                'label' => __( 'Tab Title', 'wavee-core' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
            ]
        );

        $repeater->add_control(
            'tab_content', [
                'label' => __( 'Content', 'wavee-core' ),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
            ]
        );

        $this->add_control(
            'tabs',
            [
                'label' => __( 'Tabs', 'wavee-core' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ tab_title }}}',
            ]
        );

        $this->end_controls_section();


        //--------------------------------------- Section Background --------------------------------------//
        $this->start_controls_section(
            'sec_bg_style',
            [
                'label' => __( 'Section Background', 'wavee-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'sec_padding',
            [
                'label' => __( 'Padding', 'wavee-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .sec_pad' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        $tabs = $this->get_settings_for_display( 'tabs' );
        $id_int = substr( $this->get_id_int(), 0, 3 );
        ?>
        <div id="accordion" class="faq_accordion">
            <?php
            foreach ( $tabs as $index => $item ) :
                $tab_count = $index + 1;

                $tab_title_setting_key = $this->get_repeater_setting_key( 'tab_title', 'tabs', $index );
                $this->add_render_attribute( $tab_title_setting_key, [
                    'class' => [ $tab_count == 1 ? 'btn btn-link' : 'btn btn-link collapsed' ],
                    'data-toggle' => 'collapse',
                    'data-target' => '#'.'collapse'. $id_int .$tab_count,
                    'aria-expanded' => $tab_count == 1 ? 'true' : 'false',
                    'aria-controls' => 'collapse'.$id_int .$tab_count,


                ]);

                $tab_content_setting_key = $this->get_repeater_setting_key( 'tab_content', 'tabs', $index );
                $this->add_render_attribute( $tab_content_setting_key, [
                    'id' => 'collapse'.$id_int.$tab_count,
                    'class' => [ $tab_count == 1 ? 'collapse show' : 'collapse' ],
                    'aria-labelledby' =>  $id_int.$tab_count,
                    'data-parent' => "#accordion",
                ]);
                ?>
                <div class="card">
                    <div class="card-header" id="<?php echo esc_attr( $id_int.$tab_count ) ?>">
                        <h5 class="mb-0">
                            <button <?php echo $this->get_render_attribute_string( $tab_title_setting_key ); ?>>
                                <i class="ti-plus"></i><i class="ti-minus"></i>
                                <?php echo esc_html( $item['tab_title'] ) ?>
                            </button>
                        </h5>
                    </div>
                    <div <?php echo $this->get_render_attribute_string( $tab_content_setting_key ); ?>>
                        <div class="card-body">
                            <?php echo wp_kses_post(wpautop($item['tab_content'] )) ?>
                        </div>
                    </div>
                </div>
                <?php
            endforeach; ?>
        </div>
        <?php
    }
}