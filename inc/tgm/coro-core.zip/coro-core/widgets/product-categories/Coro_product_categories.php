<?php
namespace CoroCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use WP_Query;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Text Typing Effect
 *
 * Elementor widget for text typing effect.
 *
 * @since 1.7.0
 */
class Coro_product_categories extends Widget_Base {

    public function get_name() {
        return 'coro_product_categories';
    }

    public function get_title() {
        return __( 'Product Categories', 'coro-core' );
    }

    public function get_icon() {
        return ' eicon-cart-medium';
    }

    public function get_categories() {
        return [ 'coro-elements' ];
    }

    protected function _register_controls() {
        /**
         * ====== Repeater ======
         * Slides
         */
        $cats = new \Elementor\Repeater();
        $cats->add_control(
            'cat_id', [
                'label' => __( 'Category Name', 'coro-core' ),
                'description' => __( 'Choose a category name to display.', 'coro-core' ),
                'separator' => 'before',
                'type' => Controls_Manager::SELECT,
                'options' => coro_cat_array('product_cat'),
                'default' => 'uncategorized'
            ]
        );

        $cats->add_control(
            'column', [
                'label' => __( 'Column', 'coro-core' ),
                'description' => __( 'Choose a column size you want to place in the category.', 'coro-core' ),
                'separator' => 'before',
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '6' => '12/6 (half of the full width)',
                    '4' => '12/4 (33% of the full width)',
                    '3' => '12/3 (25% of the full width)',
                ],
                'default' => '6',
            ]
        );

        $cats->add_control(
            'title', [
                'label' => __( 'Title', 'coro-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'OFF EVERYTHING',
            ]
        );

        $cats->add_control(
            'discount', [
                'label' => __( 'Discount', 'coro-core' ),
                'type' => Controls_Manager::NUMBER,
            ]
        );

        $cats->add_control(
            'btn_title', [
                'label' => __( 'Button Title', 'coro-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Shop Now',
            ]
        );


        /** ====== Category Filters ====== */
        $this->start_controls_section(
            'cats_sec', [
                'label' => __( 'Category Filters', 'coro-core' ),
            ]
        );

        $this->add_control(
            'style', [
                'label' => __( 'Style', 'coro-core' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    '1' => [
                        'title' => __( 'Simple Product Categories', 'coro-core' ),
                        'icon' => 'product-cats-1',
                    ],
                    '2' => [
                        'title' => __( 'Grid Masonry Product Categories', 'coro-core' ),
                        'icon' => 'product-cats-2',
                    ],
                ],
                'toggle' => true,
                'default' => '1',
            ]
        );

        $this->add_control(
            'show_count', [
                'label' => esc_html__( 'Show Categories', 'coro-core' ),
                'type' => Controls_Manager::NUMBER,
                'label_block' => true,
                'default' => 4,
                'condition' => [
                    'style' => ['1']
                ]
            ]
        );

        $this->add_control(
            'categories', [
                'label' => __( 'Categories', 'coro-core' ),
                'type' => Controls_Manager::REPEATER,
                'title_field' => '{{{ cat_id }}}',
                'fields' => $cats->get_controls(),
                'condition' => [
                    'style' => ['2']
                ]
            ]
        );

        $this->end_controls_section();


        /**
         * @@
         * Style Tab
         * @@
         */
        //------------------------------ Style 01 Category Text ------------------------------
        $this->start_controls_section(
            'cat01_style_colors', [
                'label' => esc_html__( 'Category Text', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['1']
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'typography_cat',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .category_area .category_gallery_item h6'
            ]
        );

        $this->start_controls_tabs(
            'cats_style_tabs'
        );

        //----------------- Normal-----------------------//
        $this->start_controls_tab(
            'cats_style_normal_tabs',
            [
                'label' => __( 'Normal', 'coro-core' ),
            ]
        );

        $this->add_control(
            'item_normal_color', [
                'label' => esc_html__( 'Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .category_area .category_gallery_item h6' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        //----------------- Normal-----------------------//
        $this->start_controls_tab(
            'cats_style_hover_tabs',
            [
                'label' => __( 'Hover', 'coro-core' ),
            ]
        );

        $this->add_control(
            'item_hover_color', [
                'label' => esc_html__( 'Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .category_area .category_gallery_item h6:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->end_controls_section();


        //------------------------------ Style 02 Category Text -----------------------------------//
        $this->start_controls_section(
            'cat02_style_colors', [
                'label' => esc_html__( 'Category Text', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['2']
                ]
            ]
        );

        $this->add_control(
            'cat2_text_color', [
                'label' => esc_html__( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pr_categorie_item .categorie_tag' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'cat2_bg_color', [
                'label' => esc_html__( 'Background Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pr_categorie_item .categorie_tag' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'cat2_text_typo',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .pr_categorie_item .categorie_tag'
            ]
        );

        $this->end_controls_section();


        //------------------------------ Style 02 Category Title  -----------------------------------//
        $this->start_controls_section(
            'cat02_title_style', [
                'label' => esc_html__( 'Title', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['2']
                ]
            ]
        );

        $this->add_control(
            'cat2_title_color', [
                'label' => esc_html__( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pr_categorie_item .hover_content h5' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'cat2_title_typo',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .pr_categorie_item .hover_content h5'
            ]
        );

        $this->end_controls_section();


        //------------------------------ Style 02 Discount Title  -----------------------------------//
        $this->start_controls_section(
            'cat02_discount_style', [
                'label' => esc_html__( 'Discount', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['2']
                ]
            ]
        );

        $this->add_control(
            'cat2_discount_color', [
                'label' => esc_html__( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pr_categorie_item .hover_content .rate_off' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();


        //------------------------------ button style ------------------------------
        $this->start_controls_section(
            'cat_btn_style', [
                'label' => esc_html__( 'Button', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['2']
                ]
            ]
        );

        $this->start_controls_tabs(
            'btn_style_tabs'
        );

        //----------------- Normal-----------------------//
        $this->start_controls_tab(
            'btn_style_normal',
            [
                'label' => __( 'Normal', 'coro-core' ),
            ]
        );

        $this->add_control(
            'normal_btn_font_color', [
                'label' => esc_html__( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shop_btn_two' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'normal_btn_bg_color', [
                'label' => esc_html__( 'Background Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shop_btn_two' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'normal_btn_border_color', [
                'label' => esc_html__( 'Border Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shop_btn_two' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        //----------------- Normal-----------------------//
        $this->start_controls_tab(
            'btn_style_hover',
            [
                'label' => __( 'Hover', 'coro-core' ),
            ]
        );

        $this->add_control(
            'hover_btn_text_color', [
                'label' => esc_html__( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shop_btn_two:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_btn_bg_color', [
                'label' => esc_html__( 'Background Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shop_btn_two:hover' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_btn_border_color', [
                'label' => esc_html__( 'Border Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shop_btn_two:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->end_controls_section();


        //------------------------------ Style 02 Item Image Box ------------------------------
        $this->start_controls_section(
            'item_img_box_style', [
                'label' => esc_html__( 'Item Box Color', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['2']
                ]
            ]
        );

        $this->add_control(
            'item_img_box_hover_color', [
                'label' => esc_html__( 'Background Hover', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pr_categorie_item .hover_content' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        //------------------------------ Section Background ------------------------------
        $this->start_controls_section(
            'sec_bg_style', [
                'label' => esc_html__( 'Style Background', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['1']
                ]
            ]
        );

        $this->add_responsive_control(
            'sec_padding',
            [
                'label' => __( 'Padding', 'plugin-domain' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .category_area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings();

        if ( $settings['style'] == '1' ) {
            include 'product-cats-1.php';
        }

        if ( $settings['style'] == '2' ) {
            wp_enqueue_script( 'imagesloaded' );
            wp_enqueue_script( 'isotope' );
            include 'product-cats-2.php';
        }
    }

}