<section class="category_area">
    <div class="container-fluid">
        <div class="row m10">
            <?php
            $cats = get_terms(array(
                'taxonomy' => 'product_cat',
                'hide_empty' => true
            ));
            if( is_array( $cats )) {
                $i = 0;
                foreach ( $cats as $cat ) {
                    $thumbnail_id = get_term_meta( $cat->term_id, 'thumbnail_id', true );
                    $image_url = wp_get_attachment_url( $thumbnail_id );
                    if( $i == $settings['show_count'] ) {
                        break;
                    }
                    if ( empty($image_url) ) {
                        $i++;
                        continue;
                    }
                    ?>
                    <div class="category_gallery_item">
                        <a href="<?php echo get_term_link($cat); ?>">
                            <h6> <?php echo esc_html($cat->name) ?> </h6>
                        </a>
                        <?php if ( $image_url ) : ?>
                            <a href="<?php echo get_term_link($cat); ?>" class="img_hover">
                                <?php echo wp_get_attachment_image( $thumbnail_id, 'coro_328x428' ) ?>
                            </a>
                        <?php endif ?>
                    </div>
                    <?php
                    ++$i;
                }
            }
            ?>
        </div>
    </div>
</section>