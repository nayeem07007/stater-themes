<?php
wp_enqueue_script( 'imagesloaded' );
wp_enqueue_script( 'isotope' );
?>
<section class="categorie_area">
    <div class="container-fluid">
        <div class="row m0" id="categorie_gallery">
            <div class="col-lg-3 col-md-6 grid-sizer"></div>
            <?php
            $cats = get_terms( array(
                'taxonomy' => 'product_cat',
                'hide_empty' => true
            ));
            foreach ( $settings['categories'] as $cat ) {
                $term = get_term_by( 'slug', $cat['cat_id'], 'product_cat' );
                $thumbnail_id = isset($term->term_id) ? get_term_meta( $term->term_id, 'thumbnail_id', true ) : '';
                $image_url = wp_get_attachment_url( $thumbnail_id );

                if ( !empty($image_url) ) { ?>
                    <div class="col-lg-<?php echo esc_attr($cat['column']) ?> col-md-6 pr_categorie_item">
                        <?php echo ($thumbnail_id) ? wp_get_attachment_image($thumbnail_id, 'full') : ''; ?>
                        <?php if ( isset($term->name) ) : ?>
                            <div class="categorie_tag"><?php echo esc_html($term->name) ?></div>
                        <?php endif; ?>
                        <div class="hover_content">
                            <div class="text">
                                <?php
                                if ( !empty( $cat['discount'] ) ) {
                                    echo '<div class="rate_off">' . esc_html($cat['discount']) . '%</div>';
                                }
                                if ( !empty( $cat['title'] ) ) {
                                    echo '<h5>' . esc_html( $cat['title'] ) . '</h5>';
                                }
                                if ( !empty( $cat['btn_title'] ) ) {
                                    echo '<a href="'. get_term_link($term->term_id) .'" class="shop_btn_two">' . esc_html( $cat['btn_title'] ) . '</a>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } ?>
        </div>
    </div>
</section>

<script>
    ;(function($){
        "use strict";
        $(document).ready(function () {
            function categorieMasonry() {
                var portfolios = $("#categorie_gallery");
                if( portfolios.length ){
                    portfolios.imagesLoaded( function() {
                        portfolios.isotope({
                            itemSelector: ".pr_categorie_item",
                            layoutMode: 'masonry',
                            masonry: {
                                columnWidth: '.grid-sizer',
                            }
                        });
                    })
                }
            }
            categorieMasonry();
        });
    })(jQuery);
</script>