<?php
namespace CoroCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/**
 * Text Typing Effect
 *
 * Elementor widget for text typing effect.
 *
 * @since 1.7.0
 */
class Coro_testimonials extends \Elementor\Widget_Base {

    public function get_name() {
        return 'coro_testimonial';
    }

    public function get_title() {
        return __( 'Coro Testimonials', 'coro-core' );
    }

    public function get_icon() {
        return ' eicon-testimonial-carousel';
    }

    public function get_categories() {
        return [ 'coro-elements' ];
    }

    public function get_style_depends() {
        return [ 'slick-theme', 'owl-carousel' ];
    }

     public function get_script_depends() {
        return [ 'owl-carousel', 'slick', 'imagesloaded', 'isotope', 'swiper' ];
    }

    protected function _register_controls() {


        /** ====== Select Style ====== **/
        $this->start_controls_section(
            'select_style', [
                'label' => __( 'Style', 'coro-core' ),
            ]
        );

        $this->add_control(
            'style', [
                'label' => __( 'Style', 'coro-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1'  => __( 'Three Column (Carousel)', 'coro-core' ),
                    '2' => __( 'One Column (Carousel)', 'coro-core' ),
                ],
                'default' => '1',
            ]
        );

        $this->end_controls_section();


        //----------------------------------------- Testimonials List ---------------------------------------------//
        $this->start_controls_section(
            'testimonials_sec',
            [
                'label' => __( 'Content', 'coro-core' ),
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'author_name', [
                'label' => __( 'Author Name', 'coro-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'IRYNA PETRUNKO'
            ]
        );

        $repeater->add_control(
            'designation', [
                'label' => __( 'Designation', 'coro-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'author_image', [
                'label' => __( 'Author Image', 'coro-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'contents', [
                'label' => __( 'Contents', 'coro-core' ),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
            ]
        );

        $this->add_control(
            'testimonials',
            [
                'label' => __( 'Testimonials', 'coro-core' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ author_name }}}',
            ]
        );

        $this->end_controls_section();


        /**
         * @@
         * Style Tabs
         * @@
         */
        /// -------------------------------------------- Style Author Name -----------------------------------------///
        $this->start_controls_section(
            'style_author_name', [
                'label' => __( 'Author Name', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'author_name_color', [
                'label' => __( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial_content .author h2' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'author_name_typo',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '
                    {{WRAPPER}} .testimonial_content .author h2
                ',
            ]
        );

        $this->end_controls_section();


        /// ------------------------------------------- Style Author Designation -----------------------------------///
        $this->start_controls_section(
            'style_designation', [
                'label' => __( 'Designation', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'designation_color', [
                'label' => __( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial_content .author h2 span' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'designation_typo',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '
                    {{WRAPPER}} .testimonial_content .author h2 span
                ',
            ]
        );

        $this->end_controls_section();


        // ----------------------------------------------- Style Background -----------------------------------------//
        $this->start_controls_section(
            'style_bg_sec', [
                'label' => __( 'Background', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'sec_padding', [
                'label' => __( 'Padding', 'coro-core' ),
                'description' => __( 'Padding around the testimonial items', 'coro-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial_slider' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $testimonials = isset($settings['testimonials']) ? $settings['testimonials'] : '';

        if ( $settings['style'] == '1' ) { ?>
            <div class="testimonial_slider" id="testimonial_one">
                <?php
                if ( !empty( $testimonials ) ) {
                    $i = 1;
                    foreach ( $testimonials as $testimonial ) { ?>
                        <div class="item">
                            <div class="testimonial_content" data-text="0<?php echo esc_attr( $i++) ?>">
                                <?php
                                if ( !empty( $testimonial['contents'] ) ) {
                                    echo wp_kses_post( wpautop( $testimonial['contents'] ) );
                                } ?>
                                <div class="author">
                                    <?php
                                    if ( !empty( $testimonial['author_image']['id'] ) ) {
                                        echo wp_get_attachment_image( $testimonial['author_image']['id'], 'coro_40x40' );
                                    }
                                    if ( !empty( $testimonial['author_name'] ) ) {
                                        echo '<h2>' . esc_html( $testimonial['author_name'] ) .'<span>/'. esc_html( $testimonial[ 'designation'] ) . '</span></h2>';
                                    } ?>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                } ?>
            </div>
            <?php
        } elseif ( $settings['style'] == '2' ) { ?>
            <div class="coro_single_testimonials">
                <div class="testimonial_slider" id="testimonial_two">
                    <?php
                    if ( !empty( $testimonials ) ) {
                        $i = 1;
                        foreach ( $testimonials as $testimonial ) { ?>
                            <div class="item">
                                <div class="testimonial_content" data-text="0<?php echo esc_attr( $i++) ?>">
                                    <?php
                                    if ( !empty( $testimonial['contents'] ) ) {
                                        echo wp_kses_post( wpautop( $testimonial['contents'] ) );
                                    } ?>
                                    <div class="author">
                                        <?php
                                        if ( !empty( $testimonial['author_image']['id'] ) ) {
                                            echo wp_get_attachment_image( $testimonial['author_image']['id'], 'coro_40x40' );
                                        }
                                        if ( !empty( $testimonial['author_name'] ) ) {
                                            echo '<h2>' . esc_html( $testimonial['author_name'] ) .'<span>/'. esc_html( $testimonial[ 'designation'] ) . '</span></h2>';
                                        } ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    } ?>
                </div>
            </div>
            <?php
        } ?>

        <script>
            ;(function($){
                "use strict";
                $(document).ready(function () {
                    if($('#testimonial_one').length){
                        $('#testimonial_one').not('.slick-initialized').slick({
                            slidesToShow: 3,
                            slidesToScroll: 1,
                            arrows: false,
                            dots: true,
                            responsive: [
                                {
                                    breakpoint: 1024,
                                    settings: {
                                        slidesToShow: 2,
                                        slidesToScroll: 2,
                                        infinite: true,
                                    }
                                },
                                {
                                    breakpoint: 600,
                                    settings: {
                                        slidesToShow: 2,
                                        slidesToScroll: 2
                                    }
                                },
                                {
                                    breakpoint: 580,
                                    settings: {
                                        slidesToShow: 1,
                                        slidesToScroll: 1
                                    }
                                }
                            ]
                        });
                    }
                    if($('#testimonial_two').length){
                        $('#testimonial_two').not('.slick-initialized').slick({
                            slidesToShow: 1,
                            slidesToScroll: 1,
                            arrows: false,
                            dots: true,
                        });
                    }
                });
            })(jQuery);
        </script>
        <?php
    }
}