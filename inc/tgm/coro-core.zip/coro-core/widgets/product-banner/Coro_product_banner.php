<?php
namespace CoroCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use WP_Query;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/**
 *
 * Coro Products
 */
class Coro_product_banner extends Widget_Base {
    public function get_name() {
        return 'coro_product_banner';
    }

    public function get_title() {
        return __( 'Product Banner', 'coro-core' );
    }

    public function get_icon() {
        return ' eicon-banner';
    }

    public function get_categories() {
        return [ 'coro-elements' ];
    }

    protected function _register_controls() {


        //--------------------------------------------- Title Section -----------------------------------------------//
        $this->start_controls_section(
            'sec_title', [
                'label' => __( 'Product Banner', 'chaoz-core' ),
            ]
        );

        $this->add_control(
            'title', [
                'label' => esc_html__( 'Title', 'saasland-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Shop By Brand',
            ]
        );

        $this->add_control(
            'price', [
                'label' => esc_html__( 'Price', 'saasland-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'From $99.00',
            ]
        );

        $this->add_control(
            'banner_img', [
                'label' => esc_html__( 'Banner Image', 'saasland-core' ),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'product_url', [
                'label' => esc_html__( 'Product URL', 'saasland-core' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#'
                ]
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings();

        ?>
        <div class="product_add_img">
            <a href="<?php echo esc_url( $settings['product_url']['url'] ) ?>" <?php coro_is_exno( $settings['product_url'] ) ?> class="product_add_contain">
                <div class="img_overlay" style="background: url(<?php echo esc_url( $settings['banner_img']['url'] ) ?>)  no-repeat;"></div>
                <?php
                 if ( !empty( $settings['title'] ) ) {
                     echo '<h4>'.esc_html( $settings['title'] ).'</h4>';
                 }
                 if ( !empty( $settings['price'] ) ) {
                     echo '<span class="price">'.esc_html( $settings['price'] ).'</span>';
                 }
                 ?>
            </a>
        </div>
        <?php
    }

}