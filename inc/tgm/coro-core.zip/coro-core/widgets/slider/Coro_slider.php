<?php
namespace CoroCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Coro_slider
 * @package CoroCore\Widgets
 */
class Coro_slider extends Widget_Base {

    public function get_name() {
        return 'coro_slider';
    }

    public function get_title() {
        return __( 'Slider', 'coro-hero' );
    }

    public function get_icon() {
        return 'eicon-post-slider';
    }

    public function get_categories() {
        return [ 'coro-elements' ];
    }

    public function get_style_depends() {
        return [ 'elegant-icon' ];
    }

    protected function render() {
        $settings = $this->get_settings();
        $slides = isset($settings['slides']) ? $settings['slides'] : '';
        $slides2 = isset($settings['slides2']) ? $settings['slides2'] : '';
        if ( $settings['style'] == '1' ) {
            wp_enqueue_style( 'slick' );
            wp_enqueue_script( 'slick' );
            include 'slider-1.php';
        }
        if ( $settings['style'] == '2' ) {
            wp_enqueue_style( 'swiper' );
            wp_enqueue_script( 'swiper' );
            include 'slider-2.php';
        }
        if ( $settings['style'] == '3' ) {
            wp_enqueue_style( 'swiper' );
            wp_enqueue_script( 'swiper' );
            include 'slider-3.php';
        }
        if ( $settings['style'] == '4' ) {
            wp_enqueue_style( 'swiper' );
            wp_enqueue_script( 'swiper' );
            include 'slider-4.php';
        }
    }

    protected function _register_controls() {

        /** ====== Choose Slider ====== **/
        $this->start_controls_section(
            'choose_slider', [
                'label' => __( 'Choose Slider', 'coro-core' ),
            ]
        );

        $this->add_control(
            'important_note',
            [
                'label' => '',
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => __( '<strong>Please note!</strong> <p>For better view, <a href="https://is.gd/H0JYVo" target="_blank">make the section and page Full-width.</a></p>', 'coro-core' ),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
            ]
        );

        $this->add_control(
            'style', [
                'label' => __( 'Slide Style', 'coro-core' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    '1' => [
                        'title' => __( 'Featured Image with Title', 'coro-core' ),
                        'icon' => 'slider1',
                    ],
                    '2' => [
                        'title' => __( 'Featured Image with Title & Subtitle', 'coro-core' ),
                        'icon' => 'slider2',
                    ],
                    '3' => [
                        'title' => __( 'Right', 'plugin-domain' ),
                        'icon' => 'slider3',
                    ],
                    '4' => [
                        'title' => __( 'Featured Image with Title', 'plugin-domain' ),
                        'icon' => 'slider4',
                    ],
                ],
                'toggle' => true,
                'default' => '1',
            ]
        );

        $this->end_controls_section();

        /**
         * ====== Repeater ======
         * Slides
         */
        $this->start_controls_section(
            'slider1_sec', [
                'label' => __( 'Slider', 'coro-core' ),
                'condition' => [
                    'style' => ['1', '2', '3']
                ]
            ]
        );

        $slides = new \Elementor\Repeater();

        $slides->add_control(
            'f_img', [
                'label' => __( 'Image', 'coro-core' ),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $slides->add_control(
            'btn_title', [
                'label' => __( 'Button Title', 'coro-core' ),
                'separator' => 'before',
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Get Started'
            ]
        );

        $slides->add_control(
            'btn_url', [
                'label' => __( 'Button URL', 'coro-core' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#'
                ]
            ]
        );

        $slides->add_control(
            'btn_color', [
                'label' => __( 'Button Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .shop_btn' => 'color: {{VALUE}};',
                    '{{WRAPPER}} {{CURRENT_ITEM}} .shop_btn::before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} {{CURRENT_ITEM}} .shop_btn_two' => 'background: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );

        $slides->add_control(
            'btn_hover_color', [
                'label' => __( 'Button Hover Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .shop_btn:hover' => 'color: {{VALUE}}; border-color: {{VALUE}};',
                    '{{WRAPPER}} {{CURRENT_ITEM}} .shop_btn::after' => 'background: {{VALUE}};',
                    '{{WRAPPER}} {{CURRENT_ITEM}} .shop_btn_two:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} {{CURRENT_ITEM}} .shop_btn_two:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $slides->add_control(
            'content', [
                'label' => __( 'Content', 'coro-core' ),
                'separator' => 'before',
                'type' => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'default' => '<h2>Padded Bag</h2>'
            ]
        );

        $slides->add_control(
            'bg_color', [
                'label' => __( 'Background Color', 'coro-core' ),
                'type' =>  \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .bg_slider' => 'background: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_control(
            'slides', [
                'label' => __( 'Slide Items', 'coro-core' ),
                'type' => Controls_Manager::REPEATER,
                'title_field' => '{{{ content }}}',
                'fields' => $slides->get_controls(),
            ]
        );

        $this->end_controls_section();


        /**
         * ====== Repeater ======
         * Slides Style 04
         */
        $this->start_controls_section(
            'slides2_sec',
            [
                'label' => __( 'Slider', 'plugin-name' ),
                'condition' => [
                    'style' => ['4']
                ]
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'title', [
                'label' => __( 'Title', 'coro-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'HOODIE<br>GOLF'
            ]
        );

        $repeater->add_control(
            'f_img', [
                'label' => __( 'Featured Image', 'coro-core' ),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'item_title', [
                'label' => __( 'Item Title', 'coro-core' ),
                'separator' => 'before',
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Wardrobe 56 items'
            ]
        );

        $repeater->add_control(
            'btn_label', [
                'label' => __( 'Button Label', 'coro-core' ),
                'separator' => 'before',
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Explore'
            ]
        );

        $repeater->add_control(
            'btn_url', [
                'label' => __( 'Button URL', 'coro-core' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#'
                ]
            ]
        );

        $repeater->add_control(
            'btn_color', [
                'label' => __( 'Button Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .slider_content_right h6' => 'color: {{VALUE}};',
                    '{{WRAPPER}} {{CURRENT_ITEM}} .slider_content_right h6 span' => 'background: {{VALUE}};',
                ],
            ]
        );

        $repeater->add_control(
            'btn_hover_color', [
                'label' => __( 'Button Hover Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .slider_content_right h6:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} {{CURRENT_ITEM}} .slider_content_right h6 span:hover' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'slides2',
            [
                'label' => __( 'Slide Items', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();


        
        /** ====== Slider Settings ====== **/
        $this->start_controls_section(
            'slider_settings', [
                'label' => __( 'Slider Settings', 'coro-core' ),
            ]
        );

        $this->add_control(
            'loop', [
                'label' => __( 'Loop', 'coro-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            ]
        );

        $this->add_control(
            'delay_duration', [
                'label' => __( 'Delay Duration', 'coro-core' ),
                'description' => __( 'Delay between transitions (in ms). If this parameter is not specified, auto play will be disabled.', 'coro-core' ),
                'type' => Controls_Manager::NUMBER,
                'default' => 5000
            ]
        );

        $this->add_control(
            'transition_anim', [
                'label' => __( 'Transition Effect', 'coro-core' ),
                'type' => Controls_Manager::ANIMATION,
            ]
        );

        $this->end_controls_section();


        /** ====== Content Styling ======  */
        $this->start_controls_section(
            'content_styling_sec', [
                'label' => esc_html__( 'Content Styling', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => [ '1', '2', '3' ]
                ]
            ]
        );

        $this->add_control(
            'h1_color', [
                'label' => __( 'Heading One Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} h1' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'h1_typo',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} h1',
            ]
        );

        $this->add_control(
            'h2_color', [
                'label' => __( 'Heading Two Color', 'coro-core' ),
                'separator' => 'before',
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} h2' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'h2_typo',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} h2',
            ]
        );

        $this->add_control(
            'h3_color', [
                'label' => __( 'Heading Three Color', 'coro-core' ),
                'separator' => 'before',
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} h3' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'h3_typo',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} h3',
            ]
        );

        $this->add_control(
            'h4_color', [
                'label' => __( 'Heading Four Color', 'coro-core' ),
                'separator' => 'before',
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} h4' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'h4_typo',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} h4',
            ]
        );

        $this->add_control(
            'h5_color', [
                'label' => __( 'Heading Five Color', 'coro-core' ),
                'separator' => 'before',
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} h5' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'h5_typo',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} h5',
            ]
        );

        $this->add_control(
            'h6_color', [
                'label' => __( 'Heading Six Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} h6' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'h6_bg_color', [
                'label' => __( 'Background Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} h6::before' => 'background: {{VALUE}};',
                ],
                'condition' => [
                    'style' => ['2']
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'h6_typo',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} h6',
            ]
        );

        $this->end_controls_section();


        /** ===================================== Title Style ===================================  */
        $this->start_controls_section(
            'slider2_style_title', [
                'label' => esc_html__( 'Title', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => [ '4' ]
                ]
            ]
        );

        $this->add_control(
            'slider2_title_color', [
                'label' => __( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider_four_area .swiper-slide .slider_content_wrapp h1' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'slider2_title_typo',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .slider_four_area .swiper-slide .slider_content_wrapp h1',
            ]
        );

        $this->end_controls_section();


        /** ===================================== Item Style ===================================  */
        $this->start_controls_section(
            'slider2_style_item', [
                'label' => esc_html__( 'Item', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => [ '4' ]
                ]
            ]
        );

        $this->add_control(
            'slider2_item_color', [
                'label' => __( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider_four_area .swiper-slide .slider_content_right h5' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'slider2_item_typo',
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .slider_four_area .swiper-slide .slider_content_right h5',
            ]
        );

        $this->end_controls_section();

    }
}
