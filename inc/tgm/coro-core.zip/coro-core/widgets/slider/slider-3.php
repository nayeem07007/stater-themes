<section class="main_slider slider_area_three swiper-container">
    <div class="swiper-wrapper">
        <?php
        foreach ( $slides as $slide ) :
            $bg_image = !empty($slide['f_img']['url']) ? "style='background: url({$slide['f_img']['url']})'" : '';
            ?>
            <div class="swiper-slide elementor-repeater-item-<?php echo $slide['_id'] ?>">
                <div class="background_bg" data-swiper-parallax="35%" <?php echo $bg_image; ?>></div>
                <div class="container custom-container">
                    <div class="slider_three_content">
                        <?php
                        if ( !empty($slide['content']) ) {
                            echo wp_kses_post($slide['content']);
                        }
                        if ( !empty($slide['btn_title']) ) : ?>
                            <a href="<?php echo esc_url($slide['btn_url']['url']) ?>" <?php coro_is_exno($slide['btn_url']) ?> class="shop_btn_two">
                                <?php echo esc_html($slide['btn_title']) ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php
        endforeach;
        ?>
    </div>
    <div class="swiper-pagination"></div>
</section>

<script>
    ;(function($){
        "use strict";
        $(document).ready(function () {
            var carousel = $(".slider_area_three");
            if(carousel.length){
                var swiper = new Swiper(carousel, {
                    slidesPerView: 1,
                    effect: <?php echo !empty($settings['transition_anim']) ? "'".$settings['transition_anim']."'" : "'".'fade'."'"; ?>,
                    speed: 1000,
                    autoplayDisableOnInteraction: false,
                    loop: <?php echo ($settings['loop'] == 'yes') ? 'true' : 'false'; ?>,
                    parallax: true,
                    pagination: {
                        el: '.swiper-pagination',
                        clickable: true,
                        renderBullet: function (index, className) {
                            return '<span class="' + className + '">' + (index + 1) + '</span>';
                        }
                    },
                    <?php if ( !empty($settings['delay_duration']) ) : ?>
                        autoplay: {
                            delay: <?php echo esc_js($settings['delay_duration']); ?>,
                        },
                    <?php endif; ?>
                });
            }
        });
    })(jQuery)
</script>