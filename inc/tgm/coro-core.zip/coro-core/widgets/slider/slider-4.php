<section class="main_slider slider_four_area swiper-container">
    <div class="swiper-wrapper">
        <?php
        if ( !empty( $slides2 ) ) {
            foreach ( $slides2 as $slide ) { ?>
                <div class="swiper-slide elementor-repeater-item-<?php echo esc_attr($slide['_id']) ?>">
                    <div class="slider_content_wrapp">
                        <div class="slider_content">
                        <?php
                        if ( !empty( $slide['title']) ) {
                            echo '<h3><span><small>'. wp_kses_post(nl2br( $slide['title'] )) .'</small></span></h3>';
                        } ?>
                        </div>
                    </div>
                    <div class="slider_img_wrap">
                        <?php
                        if ( !empty( $slide['f_img']) ) { ?>
                            <div class="bg_slider" style="background: url( <?php echo esc_url( $slide['f_img']['url'] ) ?>);"></div>
                            <?php
                        } ?>
                    </div>
                    <div class="slider_content_right">
                        <div class="text">
                            <?php
                            if ( !empty( $slide['item_title']) ) {
                                echo '<h5>'. esc_html( $slide['item_title'] ) .'</h5>';
                            }
                            if ( !empty( $slide['btn_label'] ) ) {
                                echo '<a href="'. esc_url( $slide['btn_url']['url'] ) .'" '.coro_is_exno( $slide['btn_url'] ).'>
                                         '.esc_html( $slide['btn_label'] ) .
                                            '<span><i class="ti-angel-left"></i></span>
                                      </a>';
                            } ?>

                        </div>
                    </div>
                </div>
                <?php
            }
        } ?>
    </div>
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
</section>

<script>
    ;(function($){
        "use strict";
        $(document).ready(function () {

            function Slider_two(){
                var carousel = $(".slider_four_area,.slider_two_area");
                if(carousel.length){
                    var swiper = new Swiper(carousel, {
                        slidesPerView: 1,
                        effect: <?php echo !empty($settings['transition_anim']) ? "'".$settings['transition_anim']."'" : "'".'fade'."'"; ?>,
                        autoplayDisableOnInteraction: false,
                        loop: <?php echo ($settings['loop'] == 'yes') ? 'true' : 'false'; ?>,
                        parallax: true,
                        <?php if ( !empty($settings['delay_duration']) ) : ?>
                            autoplay: {
                                delay: <?php echo esc_js($settings['delay_duration']); ?>,
                            },
                        <?php endif; ?>
                        pagination: {
                            el: '.swiper-pagination',
                            type: 'fraction',
                        },
                        navigation: {
                            nextEl: '.swiper-button-next',
                            prevEl: '.swiper-button-prev',
                        }
                    });
                }
            }
            Slider_two();

        });
    })(jQuery);
</script>