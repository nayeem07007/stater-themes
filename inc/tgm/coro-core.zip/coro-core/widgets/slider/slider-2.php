<section class="slider_two_area main_slider swiper-container">
    <div class="swiper-wrapper">
        <?php
        foreach ( $slides as $slide ) :
            ?>
            <div class="swiper-slide elementor-repeater-item-<?php echo esc_attr($slide['_id']) ?>">
                <div class="col-lg-4 col-md-5 slider_content_wrapp">
                    <div class="slider_content">
                        <?php
                        if ( !empty($slide['content']) ) {
                            echo wp_kses_post($slide['content']);
                        }
                        if ( !empty($slide['btn_title']) ) : ?>
                            <a href="<?php echo esc_url($slide['btn_url']['url']) ?>" <?php coro_is_exno($slide['btn_url']) ?> class="shop_btn">
                                <?php echo esc_html($slide['btn_title']) ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-8 col-md-7 slider_img_wrap">
                    <div class="bg_slider" style="background: #e4f3ee;">
                    </div>
                    <div class="round"></div>
                    <?php
                    if ( !empty($slide['f_img']['id']) ) {
                        echo wp_get_attachment_image( $slide['f_img']['id'], 'full', false, array('class' => 'man_img') );
                    }
                    ?>
                </div>
            </div>
            <?php
        endforeach;
        ?>
    </div>
    <div class="swiper-pagination"></div>
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
</section>

<script>
    ;(function($){
        "use strict";
        $(document).ready(function () {
            var carousel = $(".slider_two_area");
            if(carousel.length){
                var swiper = new Swiper(carousel, {
                    slidesPerView: 1,
                    effect: <?php echo !empty($settings['transition_anim']) ? "'".$settings['transition_anim']."'" : "'".'fade'."'"; ?>,
                    autoplayDisableOnInteraction: false,
                    loop: <?php echo ($settings['loop'] == 'yes') ? 'true' : 'false'; ?>,
                    parallax: true,
                    <?php if ( !empty($settings['delay_duration']) ) : ?>
                        autoplay: {
                            delay: <?php echo esc_js($settings['delay_duration']); ?>,
                        },
                    <?php endif; ?>
                    pagination: {
                        el: '.swiper-pagination',
                        type: 'fraction',
                    },
                    navigation: {
                        nextEl: '.swiper-button-next',
                        prevEl: '.swiper-button-prev',
                    }
                });
            }
        });
    })(jQuery)
</script>