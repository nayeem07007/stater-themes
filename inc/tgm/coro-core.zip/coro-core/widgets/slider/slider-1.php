<section class="slider_one_area">
    <div class="container-fluid">
        <div class="slider_inner row">
            <div class="pr_slider">
                <?php
                foreach ( $slides as $slide ) :
                    ?>
                    <div class="item">
                        <div class="row">
                            <div class="col-md-12 slider_item">
                                <?php
                                if ( !empty($slide['content']) ) {
                                    echo wp_kses_post($slide['content']);
                                }
                                ?>
                                <?php if ( !empty($slide['f_img']['id']) ) : ?>
                                    <div class="img">
                                        <?php echo wp_get_attachment_image($slide['f_img']['id'], 'full') ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="slider_thumnill_one">
                <?php
                foreach ( $slides as $slide ) :
                    if ( !empty($slide['f_img']['id']) ) :
                        ?>
                        <div class="best_img">
                            <?php echo wp_get_attachment_image($slide['f_img']['id'], '', 'coro_350x450', array( 'class' => 'banner-1' ) ); ?>
                        </div>
                    <?php
                    endif;
                endforeach;
                ?>
            </div>
        </div>
        <div class="slider_nav">
            <i class="arrow_left left_arrow slick-arrow" style=""></i>
            <i class="arrow_right Right_arrow slick-arrow" style=""></i>
        </div>
    </div>
</section>
<script>
    ;(function($){
        "use strict";
        $(document).ready(function () {
            $('.pr_slider').not('.slick-initialized').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: false,
                infinite: true,
                autoplay: true,
                fade: true,
                prevArrow: ".left_arrow",
                nextArrow: ".Right_arrow",
                asNavFor: '.slider_thumnill_one'
            });
            $('.slider_thumnill_one').not('.slick-initialized').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                asNavFor: '.pr_slider',
                dots: false,
                infinite: true,
                focusOnSelect: true,
                arrows: false,
            });
        });
    })(jQuery)
</script>