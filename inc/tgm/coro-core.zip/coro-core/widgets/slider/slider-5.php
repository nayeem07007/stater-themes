<section class="main_slider slider_five_area">
    <div class="slider_left">
        <div class="slider_five">
            <?php
            if ( !empty( $slides2 ) ) {
                foreach ( $slides2 as $slide ) {
                    ?>
                    <div class="slider_img">
                        <div class="text">
                            <h2>open-knit sweater</h2>
                            <span>From <a href="#">$59.00</a></span>
                        </div>
                        <?php
                        if ( !empty($slide['f_img']['id']) ) {
                            echo wp_get_attachment_image( $slide['f_img']['id'], 'full' );
                        }
                        ?>
                    </div>
                    <?php
                }
            } ?>
        </div>

        <div class="slider_nav">
            <i class="ti-arrow-left Left_two slick-arrow"></i>
            <i class="ti-arrow-right Right_two slick-arrow"></i>
        </div>

    </div>

    <div class="slider_right">
        <div class="slider_five_thumb">
            <img src="img/home5/slider2.jpg" alt="">
            <img src="img/home5/slider-thum2.jpg" alt="">
            <img src="img/home5/slider2.jpg" alt="">
        </div>
    </div>

    <a href="#" class="view_btn">view all products<i class="ti-arrow-right"></i></a>
</section>