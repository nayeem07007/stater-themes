<?php
namespace CoroCore\Widgets;

use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor icon widget.
 *
 * Elementor widget that displays an icon from over 600+ icons.
 *
 * @since 1.0.0
 */
class Coro_icons extends Widget_Base {


    public function get_name() {
        return 'coro_icons';
    }

    public function get_title() {
        return __( 'Coro Icon', 'coro-core' );
    }

    public function get_icon() {
        return 'eicon-favorite';
    }

    public function get_categories() {
        return [ 'coro-elements' ];
    }

    public function get_keywords() {
        return [ 'icon' ];
    }

    public function get_style_depends()
    {
        return ['simple-line-icon'];
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'section_icon',
            [
                'label' => __( 'Icon', 'coro-core' ),
            ]
        );
        $repeater = new Repeater();
        $repeater->add_control(
            'icon_type',
            [
                'label' => __( 'Icon Type', 'coro-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'eicon' => esc_html__( 'Elegant Icon', 'coro-core' ),
                    'ticon' => esc_html__( 'Themify Icon', 'coro-core' ),
                    'slicon' => esc_html__( 'Simple Line Icon', 'coro-core' ),
                    'flaticon' => esc_html__( 'Flaticon', 'coro-core' ),
                ],
                'default' => 'eicon',
            ]
        );

        $repeater->add_control(
            'eicon',
            [
                'label' => __( 'Elegant Icon', 'coro-core' ),
                'type' => Controls_Manager::ICON,
                'options' => coro_elegant_icons(),
                'include' => coro_include_elegant_icons(),
                'condition' => [
                    'icon_type' => 'eicon'
                ]
            ]
        );

        $repeater->add_control(
            'ticon',
            [
                'label' => __( 'Themify Icon', 'coro-core' ),
                'type' => Controls_Manager::ICON,
                'options' => coro_themify_icons(),
                'include' => coro_include_themify_icons(),
                'condition' => [
                    'icon_type' => 'ticon'
                ]
            ]
        );

        $repeater->add_control(
            'slicon',
            [
                'label'     => __( 'Simple Line Icon', 'coro-core' ),
                'type'      => Controls_Manager::ICON,
                'options'   => coro_simple_line_icons(),
                'include'   => coro_include_simple_line_icons(),
                'condition' => [
                    'icon_type' => 'slicon'
                ]
            ]
        );

        $repeater->add_control(
            'flaticon',
            [
                'label'      => __( 'Flaticon', 'coro-core' ),
                'type'       => Controls_Manager::ICON,
                'options'    => coro_flaticons(),
                'include'    => coro_include_flaticons(),
                'condition'  => [
                    'icon_type' => 'flaticon'
                ]
            ]
        );

        $repeater->add_control(
            'icon_url',
            [
                'label' => __( 'Link', 'coro-core' ),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => __( 'https://your-link.com', 'coro-core' ),
            ]
        );

        $this->add_control(
            'social_icon_list',
            [
                'label' => __( 'Social Icons', 'elementor' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ ticon }}}',
            ]
        );


        $this->add_control(
            'view',
            [
                'label' => __( 'View', 'coro-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'default' => __( 'Default', 'coro-core' ),
                    'stacked' => __( 'Stacked', 'coro-core' ),
                    'framed' => __( 'Framed', 'coro-core' ),
                ],
                'default' => 'default',
                'prefix_class' => 'elementor-view-',
            ]
        );

        $this->add_control(
            'shape',
            [
                'label' => __( 'Shape', 'coro-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'circle' => __( 'Circle', 'coro-core' ),
                    'square' => __( 'Square', 'coro-core' ),
                ],
                'default' => 'circle',
                'condition' => [
                    'view!' => 'default',
                ],
                'prefix_class' => 'elementor-shape-',
            ]
        );


        $this->add_responsive_control(
            'align',
            [
                'label' => __( 'Alignment', 'coro-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'coro-core' ),
                        'icon' => 'fab fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'coro-core' ),
                        'icon' => 'fab fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'coro-core' ),
                        'icon' => 'fab fa-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .social_icon_alignment' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        /***
         * Tab Style
         */
        $this->start_controls_section(
            'section_style_icon',
            [
                'label' => __( 'Icon', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs( 'icon_colors' );

        $this->start_controls_tab(
            'icon_colors_normal',
            [
                'label' => __( 'Normal', 'coro-core' ),
            ]
        );

        $this->add_control(
            'normal_primary_color',
            [
                'label' => __( 'Primary Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .social_icon_alignment li a' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'normal_secondary_color',
            [
                'label' => __( 'Secondary Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .social_icon_alignment li a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'icon_colors_hover',
            [
                'label' => __( 'Hover', 'coro-core' ),
            ]
        );

        $this->add_control(
            'hover_primary_color',
            [
                'label' => __( 'Primary Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .social_icon_alignment li a:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_secondary_color',
            [
                'label' => __( 'Secondary Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .social_icon_alignment li a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control(
            'size',
            [
                'label' => __( 'Size', 'coro-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 6,
                        'max' => 300,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .social_icon_alignment li a' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_padding',
            [
                'label' => __( 'Padding', 'coro-core' ),
                'type' => Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .social_icon_alignment li a' => 'padding: {{SIZE}}{{UNIT}};',
                ],
                'range' => [
                    'em' => [
                        'min' => 0,
                        'max' => 5,
                    ],
                ],
            ]
        );

        $icon_spacing = is_rtl() ? 'margin-left: {{SIZE}}{{UNIT}};' : 'margin-right: {{SIZE}}{{UNIT}};';

        $this->add_responsive_control(
            'icon_spacing',
            [
                'label' => __( 'Spacing', 'elementor' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .social_icon_alignment li a' => $icon_spacing,
                ],
            ]
        );

        $this->add_responsive_control(
            'rotate',
            [
                'label' => __( 'Rotate', 'coro-core' ),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0,
                    'unit' => 'deg',
                ],
                'selectors' => [
                    '{{WRAPPER}} .social_icon_alignment li' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->add_control(
            'border_width',
            [
                'label' => __( 'Border Width', 'coro-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .social_icon_alignment li' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'view' => 'framed',
                ],
            ]
        );

        $this->add_control(
            'border_radius',
            [
                'label' => __( 'Border Radius', 'coro-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .social_icon_alignment li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'view!' => 'default',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'icon_box_shadow',
                'label' => __( 'Box Shadow', 'coro-core' ),
                'selector' => '{{WRAPPER}} .social_icon_alignment li a',
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render icon widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        $social_icons = !empty( $settings['social_icon_list'] ) ? $settings['social_icon_list'] : '';

        ?>
        <ul class="social_icon_alignment">
            <?php
            if ( !empty( $social_icons ) ) {
                foreach ( $social_icons as $social_icon ) {

                    switch ($social_icon['icon_type']) {
                        case 'eicon':
                            $icon = !empty($social_icon['eicon']) ? $social_icon['eicon'] : '';
                            break;
                        case 'ticon':
                            $icon = !empty($social_icon['ticon']) ? $social_icon['ticon'] : '';
                            break;
                        case 'slicon':
                            wp_enqueue_style( 'simple-line-icon' );
                            $icon = !empty($social_icon['slicon']) ? $social_icon['slicon'] : '';
                            break;
                        case 'flaticon':
                            $icon = !empty($social_icon['flaticon']) ? $social_icon['flaticon'] : '';
                            break;
                    }

                    $icon_class = ( !empty($icon ) ) ? $icon : '';  ?>

                    <li>
                        <a href="<?php echo esc_url( $social_icon['icon_url']['url'] ) ?>"
                            <?php coro_is_external( $social_icon['icon_url'] ) ?>>
                            <i class="<?php echo esc_attr( $icon_class ) ?>"></i>
                        </a>
                    </li>
                    <?php
                }
            } ?>
        </ul>
        <?php
    }
}