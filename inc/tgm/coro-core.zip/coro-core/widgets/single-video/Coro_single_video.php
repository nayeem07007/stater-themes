<?php
namespace CoroCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;



// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}



/**
 * Text Typing Effect
 *
 * Elementor widget for text typing effect.
 *
 * @since 1.7.0
 */
class Coro_single_video extends Widget_Base {

    public function get_name() {
        return 'coro_single_video';
    }

    public function get_title() {
        return __( 'Featured Video', 'coro-core' );
    }

    public function get_icon() {
        return 'eicon-youtube';
    }

    public function get_categories() {
        return [ 'coro-elements' ];
    }

    public function get_style_depends() {
        return [ 'magnify-popup' ];
    }

    public function get_script_depends() {
        return [ 'magnify-popup' ];
    }


    protected function _register_controls() {


        // ------------------------------ Single Video ------------------------------
        $this->start_controls_section(
            'video_sec', [
                'label' => __( 'Featured Video', 'coro-core' ),
            ]
        );

        $this->add_control(
            'video_url', [
                'label' => esc_html__( 'Video URL', 'coro-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'f_img', [
                'label' => esc_html__( 'Featured Image', 'coro-core' ),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        $this->end_controls_section();


        // ------------------- Button ---------------------- //
        $this->start_controls_section(
            'section_bg_style', [
                'label' => __( 'Section Style', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'sec_padding',
            [
                'label' => __( 'margin', 'coro-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .video_area_two' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings();
        ?>
        <section class="video_area_two">
            <div class="container custom-container">
                <div class="video_img">
                    <?php
                    if ( !empty( $settings['f_img']['id'] ) ) {
                        echo wp_get_attachment_image( $settings['f_img']['id'], 'full' );
                    }
                    if ( !empty( $settings['video_url'] ) ) {
                        echo '<a href="'. esc_url( $settings['video_url'] ) .'" class="video_icon popup-youtube"><i class="ti-control-play"></i></a>';
                    } ?>
                </div>
            </div>
        </section>

        <script>
            ;(function($){
                "use strict";
                $(document).ready(function () {

                    function popupGallery(){
                        if($('.popup-youtube').length){
                            $('.popup-youtube').magnificPopup({
                                type: 'iframe',
                                removalDelay: 160,
                                preloader: false,
                                fixedContentPos: false,
                                mainClass:  'mfp-with-zoom mfp-img-mobile',
                            });
                        }
                    }
                    popupGallery();
                });
            })(jQuery);
        </script>

        <?php
    }
}