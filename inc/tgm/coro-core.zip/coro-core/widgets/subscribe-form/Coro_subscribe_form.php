<?php
namespace CoroCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;



// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}



/**
 * Text Typing Effect
 *
 * Elementor widget for text typing effect.
 *
 * @since 1.7.0
 */
class Coro_subscribe_form extends Widget_Base {

    public function get_name() {
        return 'coro_subscribe_form';
    }

    public function get_title() {
        return __( 'Subscribe form', 'coro-core' );
    }

    public function get_icon() {
        return ' eicon-mailchimp';
    }

    public function get_categories() {
        return [ 'coro-elements' ];
    }

    public function get_keywords() {
        return [ 'mailchimp', 'form' ];
    }

    public function get_script_depends() {
        return [ 'ajax-chimp' ];
    }

    protected function _register_controls() {


        /** ====== Select Style ====== **/
        $this->start_controls_section(
            'choose_style', [
                'label' => __( 'Style', 'coro-core' ),
            ]
        );

        $this->add_control(
            'style', [
                'label' => __( 'Style', 'coro-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1'  => __( 'Style One', 'coro-core' ),
                    '2' => __( 'Style Two', 'coro-core' ),
                ],
                'default' => '1',
            ]
        );

        $this->end_controls_section();

        // ------------------------------ MailChimp form ------------------------------
        $this->start_controls_section(
            'form_settings', [
                'label' => __( 'Form settings', 'coro-core' ),
            ]
        );

        $this->add_control(
            'email_placeholder', [
                'label' => esc_html__( 'Email Filed Placeholder', 'coro-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Type your email...',
            ]
        );

        $this->add_control(
            'action_url', [
                'label' => esc_html__( 'Action URL', 'coro-core' ),
                'description' => __( 'Enter here your MailChimp action URL. <a href="https://goo.gl/k5a2tA" target="_blank"> How to </a>', 'coro-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'btn_label', [
                'label' => esc_html__( 'Submit Button', 'coro-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Subscribe',
            ]
        );

        $this->end_controls_section();


        /**
         * Style Tab
         * ------------------------------ Form Styling -----------------------------
         */
        $this->start_controls_section(
            'form_style_sec',
            [
                'label' => __( 'Form Styling', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                        'style' => '1'
                ]
            ]
        );

        $this->add_control(
            'form_border_color', [
                'label' => __( 'Border Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .f_subscribe .form-control' => 'border-color: {{VALUE}};',
                ]
            ]
        );

        $this->add_control(
            'form_submit_btn_color', [
                'label' => __( 'Submit Button Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .f_subscribe button' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'form_submit_btn_typo',
                'label' => __( 'Button Typography', 'coro-core' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .f_subscribe button',
            ]
        );

        $this->end_controls_section();


        // ------------------- Button ---------------------- //
        $this->start_controls_section(
            'btn_style', [
                'label' => __( 'Button', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => '2'
                ]

            ]
        );

        $this->start_controls_tabs(
            'btn_style_tabs'
        );

        //----------------- Normal-----------------------//
        $this->start_controls_tab(
            'style_normal_tab',
            [
                'label' => __( 'Normal', 'coro-core' ),
            ]
        );

        $this->add_control(
            'btn_text_color', [
                'label' => esc_html__( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shop_btn_two' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_bg_color', [
                'label' => esc_html__( 'Background Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shop_btn_two' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_border_color', [
                'label' => esc_html__( 'Border Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shop_btn_two' => 'border-color: {{VALUE}};',
                ],
            ]
        );


        $this->end_controls_tab();

        // ------------------ Hover ------------------------//
        $this->start_controls_tab(
            'style_hover_tab',
            [
                'label' => __( 'Hover', 'coro-core' ),
            ]
        );

        $this->add_control(
            'btn_text_color_hover', [
                'label' => esc_html__( 'Text Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shop_btn_two:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_bg_color_hover', [
                'label' => esc_html__( 'Background Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shop_btn_two:hover' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_border_color_hover', [
                'label' => esc_html__( 'Border Color', 'coro-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .shop_btn_two:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );


        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings();
        $btn_label = !empty($settings['btn_label']) ? $settings['btn_label'] : '';
        $email_placeholder = !empty($settings['email_placeholder']) ? $settings['email_placeholder'] : '';

        if ( $settings['style'] == '1' ) {
            ?>
            <form action="#" class="subscriber_one f_subscribe mailchimp" method="post" >
                <input type="text" name="EMAIL" class="form-control memail" placeholder="<?php echo esc_html( $email_placeholder ); ?>">
                <?php if ( $btn_label ) : ?>
                    <button class="btn btn-submit" type="submit">
                        <?php echo esc_html( $btn_label ); ?><i class="ti-arrow-right"></i>
                    </button>
                <?php endif; ?>
                <p class="mchimp-errmessage" style="display: none;"></p>
                <p class="mchimp-sucmessage" style="display: none;"></p>
            </form>
            <?php
        } elseif ( $settings['style'] == '2' ) {
            ?>
            <form action="#" class="subscriber_two subscribe mailchimp input-group" method="post">
                <input type="text" name="EMAIL" class="form-control memail" placeholder="<?php echo esc_html( $email_placeholder ); ?>">
                <?php if ( $btn_label ) : ?>
                    <button class="btn btn-submit shop_btn_two" type="submit">
                        <?php echo esc_html( $btn_label ); ?>
                    </button>
                <?php endif; ?>
                <div class="messages">
                    <p class="mchimp-errmessage" style="display: none;"></p>
                    <p class="mchimp-sucmessage" style="display: none;"></p>
                </div>
            </form>
            <?php
        } ?>

        <script>
            ;(function($){
                "use strict";
                $(document).ready(function () {
                    // MAILCHIMP
                    if ($(".mailchimp").length > 0) {
                        $(".mailchimp").ajaxChimp({
                            callback: mailchimpCallback,
                            url: "<?php echo esc_js($settings['action_url']) ?>"
                        });
                    }
                    $(".memail").on("focus", function () {
                        $(".mchimp-errmessage").fadeOut();
                        $(".mchimp-sucmessage").fadeOut();
                    });
                    $(".memail").on("keydown", function () {
                        $(".mchimp-errmessage").fadeOut();
                        $(".mchimp-sucmessage").fadeOut();
                    });
                    $(".memail").on("click", function () {
                        $(".memail").val("");
                    });

                    function mailchimpCallback(resp) {
                        if (resp.result === "success") {
                            $(".mchimp-errmessage").html(resp.msg).fadeIn(1000);
                            $(".mchimp-sucmessage").fadeOut(500);
                        } else if (resp.result === "error") {
                            $(".mchimp-errmessage").html(resp.msg).fadeIn(1000);
                        }
                    }
                });
            })(jQuery);
        </script>
        <?php
    }
}