<?php
global $product;

$product_badge = function_exists('get_field') ? get_field('badge_name') : '';
$badge_font_color = function_exists('get_field') ? get_field('badge_font_color') : '';
$font_color = !empty($badge_font_color) ? "color: $badge_font_color;" : '';
$badge_bg_color = function_exists('get_field') ? get_field('badge_background_color') : '';
$bg_color = !empty($badge_bg_color) ? "background: $badge_bg_color;" : '';
$remove_style = !empty($font_color) && !empty($bg_color) ? "style='$font_color $bg_color'" : '';

if ( !empty($gallery_ids) ) :
    ?>
    <div class="best_pr_slider">
        <div class="pr_img">
            <div class="inner-slider item-slider slick">
                <a href="<?php the_permalink(); ?>">
	                <?php the_post_thumbnail( 'coro_328x428', array('class' => 'primary_thumb') );?>
                </a>
                <?php
                foreach ( $gallery_ids as $gallery_id ) {
                    ?>
                    <a href="<?php the_permalink() ?>">
                        <?php echo wp_get_attachment_image( $gallery_id, 'coro_328x428', array( 'class' => 'primary_thumb' ) ); ?>
                    </a>
                    <?php
                }
                ?>
            </div>
            <div class="hover_item">
                <div class="tooltips add2cart_btn" title="<?php echo esc_attr($product->single_add_to_cart_text()) ?>">
		            <?php woocommerce_template_loop_add_to_cart() ?>
                </div>
                <div class="tooltips" title="<?php esc_attr_e('Quick View', 'coro-core'); ?>">
                    <a href="<?php the_post_thumbnail_url(); ?>" class="img_popup">
                        <i class="ti-search"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="pr_content">
	    <?php
	    if ( $product->is_on_sale() ) { ?>
            <span class="product-badge sale"> <?php esc_html_e( 'Sale', 'coro-core' ); ?> </span>
		    <?php
	    } else { ?>
            <span class="product-badge new" <?php echo wp_kses_post($remove_style) ?>>
                <?php echo esc_html( $product_badge ) ?>
            </span>
            <?php
	    }
	    ?>
        <?php
        if ( class_exists( '[ti_wishlists_addtowishlist ]' ) ) {
            echo esc_html(do_shortcode( '[ti_wishlists_addtowishlist ]' ));
        }
        ?>
    </div>
    <div class="product-details">
        <a href="<?php the_permalink(); ?>" class="pr_name">
            <?php the_title() ?>
        </a>
        <div class="product-prices">
            <?php woocommerce_template_loop_price(); ?>
        </div>
    </div>

<?php endif; ?>