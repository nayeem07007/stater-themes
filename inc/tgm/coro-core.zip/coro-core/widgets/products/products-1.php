<?php
$this->add_render_attribute( 'wrapper', 'id', 'portfolio_filter' );
    $query = new WP_Query(array(
        'post_type'           => 'product',
        'post_status'         => 'publish',
        'ignore_sticky_posts' => 1,
        'posts_per_page'      => !empty($settings['show_count']) ? $settings['show_count'] : -1,
        'order'               => !empty($settings['order']) ? $settings['order'] : 'DESC',
        'post__not_in'        => !empty($settings['exclude']) ? explode(',', $settings['exclude']) : ''
    ));
    ?>
    <div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> class="portfolio_filter mb_50">
        <?php
        if ( $settings['all_label'] ) {
            echo '<div data-filter="*" class="work_portfolio_item active">'. esc_html( $settings['all_label'] ) .'</div>';
        }
        $cats = get_terms(array(
            'taxonomy' => 'product_cat',
            'hide_empty' => true
        ));
        foreach ( $cats as $cat ) {
            echo "<div data-filter='.{$cat->slug}' class='work_portfolio_item'>{$cat->name}</div>";
        }
        ?>
    </div>
    <div class="best_pr-info">
        <?php
        while($query->have_posts()) : $query->the_post();
            global $product;
            $gallery_ids = $product->get_gallery_image_ids();
            $cats = get_the_terms(get_the_ID(), 'product_cat' );
            $cat_slug = '';
            $cats_count = count($cats);
            if ( is_array($cats) ) {
                foreach ($cats as $cat_i => $cat) {
                    $cat_i = $cat_i+1;
                    $separator = ($cat_i == $cats_count) ? '' : ' ';
                    $cat_slug .= $cat->slug.$separator;
                }
            }
            $sku_v = ( $sku = $product->get_sku() ) ? $sku : esc_html__( 'N/A', 'coro' );
            $classes = implode( ' ', array_filter( array(
                        'button',
                        'product_type_' . $product->get_type(),
                        $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
                        $product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '',
                       ))).' ';
            ?>
            <div class="<?php echo esc_attr( $settings['is_fluid_product'] == 'yes' ? 'best_pr_item' : 'best_pr_item item_box_width' ) ?> <?php echo esc_attr($cat_slug) ?>">
                <div class="best_pr_thumbnail">
                    <?php
                    if ( !empty($gallery_ids) ) :
                        include 'product-gallery.php';
                    else :
                        include 'product.php';
                    endif;
                    ?>
                </div>
            </div>
            <?php
        endwhile;
        wp_reset_postdata();
        ?>
    </div>

    <script>
        ;(function($){
            "use strict";
            $(document).ready(function () {
                function portfolioMasonry(){
                    // Add isotope click function
                    $("#portfolio_filter div").on('click',function(){
                        $("#portfolio_filter div").removeClass("active");
                        $(this).addClass("active");

                        var selector = $(this).attr("data-filter");
                        portfolio.isotope({
                            filter: selector,
                        });
                        return false;
                    });

                    var portfolio = $(".best_pr-info");
                    if( portfolio.length ){
                        portfolio.imagesLoaded( function() {
                            // images have loaded
                            // Activate isotope in container
                            portfolio.isotope({
                                itemSelector: ".best_pr_item",
                                layoutMode: 'masonry',
                                filter:"*",
                            });
                        });
                    }
                }
                portfolioMasonry();
            });
        })(jQuery)
    </script>