<?php
global $product;
?>
<section class="best_pr_area_two">
    <div class="container-fluid">
        <div class="row flex-row-reverse">
            <div class="col-lg-5">
                <div class="best_pr_info">
                    <div class="best_pr_slider_two">
						<?php
						use Elementor\Group_Control_Image_Size;

						if ( !empty($settings['cats']) ) {
							$carousel_query = new WP_Query(array(
								'post_type' => 'product',
								'post_status' => 'publish',
								'posts_per_page' => !empty($settings['show_count_carousel']) ? $settings['show_count_carousel'] : -1,
								'order' => !empty($settings['order_carousel']) ? $settings['order_carousel'] : 'DESC',
								'tax_query' => array(
									array(
										'taxonomy' => 'product_cat',
										'field'    => 'slug',
										'terms'    => $cats,
									),
								),
							));
						} else {
							$carousel_query = new WP_Query(array(
								'post_type'           => 'product',
								'post_status'         => 'publish',
								'posts_per_page'      => !empty($settings['show_count_carousel']) ? $settings['show_count_carousel'] : -1,
								'order'               => !empty($settings['order_carousel']) ? $settings['order_carousel'] : 'DESC',
							));
						}
						while( $carousel_query->have_posts()) : $carousel_query->the_post();
							global $product;
							$settings['thumbnail_size'] = [
								'id' => get_post_thumbnail_id(),
							];
							$thumbnail_html = Group_Control_Image_Size::get_attachment_image_html( $settings, 'thumbnail_size' );
							?>
                            <div class="b_item">
                                <a href="<?php the_permalink() ?>">
									<?php echo $thumbnail_html ?>
                                </a>
                                <p class="pr_code"><?php echo $product->get_sku(); ?></p>
                            </div>
						    <?php
						endwhile;
						wp_reset_postdata();
						?>
                    </div>
                    <div class="post_slider_nav">
                        <div class="left slick-arrow"><?php esc_html_e( 'PREV', 'coro-core' ) ?></div>
                        <div class="right slick-arrow"><?php esc_html_e( 'Next', 'coro-core' ) ?></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="best_pr_slider_three">
                    <?php
                    $query = new WP_Query(array(
	                    'post_type'           => 'product',
	                    'post_status'         => 'publish',
	                    'ignore_sticky_posts' => 1,
	                    'posts_per_page'      => !empty($settings['show_count']) ? $settings['show_count'] : -1,
	                    'order'               => !empty($settings['order']) ? $settings['order'] : 'DESC',
	                    'post__not_in'        => !empty($settings['exclude']) ? explode(',', $settings['exclude']) : ''
                    ));
                    ?>
                    <?php if ( !empty( $settings['title'] ) ) : ?>
                        <h2 class="h_two_title"><?php echo esc_html( $settings['title'] ) ?></h2>
                    <?php endif; ?>
                    <div class="portfolio_filter item_filter mb_50">
						<?php
						if ( !empty($settings['all_label']) ) {
							echo '<div data-filter="*" class="work_portfolio_item active">'. esc_html( $settings['all_label'] ) .'</div>';
						}
						$cats = get_terms(array(
							'taxonomy' => 'product_cat',
							'hide_empty' => true
						));
						foreach ( $cats as $cat ) {
							echo "<div data-filter='.{$cat->slug}' class='work_portfolio_item'>{$cat->name}</div>";
						}
						?>
                    </div>
                    <div class="slider_nav">
                        <i class='ti-arrow-left left_arrow'></i>
                        <i class='ti-arrow-right Right_arrow'></i>
                    </div>
                    <div class="best_pr_info_left filter_slider">
						<?php
						while( $query->have_posts()) : $query->the_post();
							$cats = get_the_terms(get_the_ID(), 'product_cat' );
							$cat_slug = '';
							if ( is_array($cats) ) {
								foreach ( $cats as  $cat ) {
									$cat_slug .= $cat->slug. ' ';
								}
							}
							?>
                            <div class="best_pr_item <?php echo esc_attr($cat_slug) ?>">
                                <div class="best_pr_thumbnail">
	                                <?php include 'product.php'; ?>
                                </div>
                            </div>
						    <?php
						endwhile;
						wp_reset_postdata();
						?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<script>
    ;(function($){
        "use strict";
        $(document).ready(function () {
            if($('.best_pr_slider_two').length){
                $('.best_pr_slider_two').slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    fade: true,
                    dots: false,
                    autoplay: true,
                    prevArrow: ".left",
                    nextArrow: ".right"
                });
            }

            $("#portfolio_filter div").on('click',function(){
                $("#portfolio_filter div").removeClass("active");
                $(this).addClass("active");

                var selector = $(this).attr("data-filter");
                portfolio.isotope({
                    filter: selector,
                    animationOptions: {
                        animationDuration: 750,
                        easing: 'linear',
                        queue: false
                    }
                })
                return false;
            })

            /*----------------------------------------------------*/
            /* Slick Cutom Fillter js
			/*----------------------------------------------------*/
            $('.item_filter div').on('click', function() {
                $('.item_filter div').removeClass('active');
                $(this).addClass('active');
                var selector = $(this).attr('data-filter');
                $('.filter_slider').fadeOut(300);
                $('.filter_slider').fadeIn(300);
                setTimeout(function() {
                    $('.filter_slider .best_pr_item').hide();
                    $(selector).closest('.filter_slider .best_pr_item').show();
                }, 300);
                return false;
            });
            
            if($('.filter_slider').length){
                $('.filter_slider').slick({
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    autoplay: true,
                    prevArrow: ".left_arrow",
                    nextArrow: ".Right_arrow",
                    responsive: [
                        {
                            breakpoint: 768,
                            settings: {
                                slidesToShow: 2,
                                slidesToScroll: 2,
                                infinite: true,
                            }
                        },
                        {
                            breakpoint: 600,
                            settings: {
                                slidesToShow: 2,
                                slidesToScroll: 2
                            }
                        },
                        {
                            breakpoint: 580,
                            settings: {
                                slidesToShow: 1,
                                slidesToScroll: 1
                            }
                        }
                    ]
                });
            }
        });
    })(jQuery)
</script>