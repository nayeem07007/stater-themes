<?php
namespace CoroCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use WP_Query;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/**
 *
 * Coro Products
 */
class Coro_products extends Widget_Base {
    public function get_name() {
        return 'coro_products';
    }

    public function get_title() {
        return __( 'Coro Products', 'coro-core' );
    }

    public function get_icon() {
        return ' eicon-products';
    }

    public function get_categories() {
        return [ 'coro-elements' ];
    }

    public function get_script_style() {
        return [ 'slick-theme', 'slick' ];
    }

    public function get_script_depends() {
        return [ 'imagesloaded', 'isotope', 'slick' ];
    }

    protected function _register_controls() {

        /** ====== Choose Product Style ====== **/
        $this->start_controls_section(
            'choose_product', [
                'label' => __( 'Choose Product', 'coro-core' ),
            ]
        );

        $this->add_control(
            'important_note',
            [
                'label' => '',
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => __( '<strong>Please note!</strong> <p>For better view, <a href="https://is.gd/H0JYVo" target="_blank">make the section and page Full-width.</a></p>', 'coro-core' ),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
            ]
        );

        $this->add_control(
            'style', [
                'label' => __( 'Product Style', 'coro-core' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    '1' => [
                        'title' => __( 'Style One', 'coro-core' ),
                        'icon' => 'product-1',
                    ],
                    '2' => [
                        'title' => __( 'Filterable Products with Carousel', 'coro-core' ),
                        'icon' => 'product-2',
                    ],
                ],
                'toggle' => true,
                'default' => '1',
            ]
        );

        $this->end_controls_section();


        //--------------------------------------------- Title Section -----------------------------------------------//
        $this->start_controls_section(
            'sec_title', [
                'label' => __( 'Title', 'chaoz-core' ),
                'condition' => [
                    'style' => '2'
                ]
            ]
        );

        $this->add_control(
            'title', [
                'label' => esc_html__( 'Title', 'saasland-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Best Sellers',
            ]
        );

        $this->end_controls_section();


        //--------------------------- Gallery Product Thumbnails ------------------------------------//
	    $this->start_controls_section(
		    'carousel_layout_opt', [
			    'label' => __( 'Product Carousel', 'coro-core' ),
			    'condition' => [
				    'style' => '2'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    \Elementor\Group_Control_Image_Size::get_type(),
		    [
			    'name' => 'thumbnail_size', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
			    'exclude' => [ 'custom' ],
			    'include' => [],
			    'default' => 'coro_610x710',
		    ]
	    );

	    $this->add_control(
		    'show_count_carousel', [
			    'label' => esc_html__( 'Show Count', 'coro-core' ),
			    'type' => Controls_Manager::NUMBER,
			    'label_block' => true,
			    'default' => 2,
		    ]
	    );

	    $this->add_control(
		    'order_carousel', [
			    'label' => esc_html__( 'Order', 'coro-core' ),
			    'description' => esc_html__( '‘ASC‘ – ascending order from lowest to highest values (1, 2, 3; a, b, c). ‘DESC‘ – descending order from highest to lowest values (3, 2, 1; c, b, a).', 'saasland-core' ),
			    'type' => Controls_Manager::SELECT,
			    'options' => [
				    'ASC' => 'ASC',
				    'DESC' => 'DESC'
			    ],
			    'default' => 'ASC'
		    ]
	    );

	    $this->end_controls_section();


        //-------------------------------------------- Filter Section -----------------------------------------------//
        $this->start_controls_section(
            'filter', [
                'label' => __( 'Filter', 'chaoz-core' ),
            ]
        );

        $this->add_control(
            'all_label', [
                'label' => esc_html__( 'All filter label', 'saasland-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'All'
            ]
        );

        $this->add_control(
            'show_count', [
                'label' => esc_html__( 'Show products', 'chaoz-core' ),
                'type' => Controls_Manager::NUMBER,
                'label_block' => true,
                'default' => 12
            ]
        );

        $this->add_control(
            'order', [
                'label' => esc_html__( 'Order', 'chaoz-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'ASC' => 'ASC',
                    'DESC' => 'DESC'
                ],
                'default' => 'ASC'
            ]
        );

        $this->add_control(
            'exclude', [
                'label' => esc_html__( 'Exclude Products', 'rogan-core' ),
                'description' => esc_html__( 'Enter the product post ID to hide. Input the multiple ID with comma separated', 'rogan-core' ),
                'type' => Controls_Manager::TEXT,
            ]
        );

        $this->add_responsive_control(
            'align',
            [
                'label' => __( 'Alignment', 'coro-core' ),
                'type' => Controls_Manager::CHOOSE,
                'condition' => [
                    'style' => [ '1', '2' ]
                ],
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'coro-core' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'coro-core' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'coro-core' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} #portfolio_filter' => 'justify-content: {{VALUE}};',
                ],
                'prefix_class' => 'elementor%s-align-',
            ]
        );

        $this->add_control(
            'is_fluid_product',
            [
                'label' => __( 'Full Width', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'your-plugin' ),
                'label_off' => __( 'No', 'your-plugin' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
                'condition' => [
                    'style' => '1',
                ]
            ]
        );

        $this->end_controls_section();


        //----------------------------------------- Section Background Style ----------------------------------------------------//
        $this->start_controls_section(
            'sec_bg_style', [
                'label' => __( 'Section Background', 'coro-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => '2'
                ]
            ]
        );

        $this->add_responsive_control(
            'sec_padding', [
                'label' => esc_html__( 'Padding', 'coro-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .best_pr_area_two' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'unit' => 'px', // The selected CSS Unit. 'px', '%', 'em',

                ],
            ]
        );

        $this->end_controls_section();


    }

    protected function render() {
        $settings = $this->get_settings();

        if ( $settings['style'] == '1' ) {
            include 'products-1.php';
        }

        if ( $settings['style'] == '2' ) {
            include 'products-2.php';
        }
    }

}