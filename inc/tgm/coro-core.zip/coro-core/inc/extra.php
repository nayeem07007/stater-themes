<?php

add_image_size( 'coro_350x450', 350, 450, true); // Slider Style 01 Thumbnail
add_image_size( 'coro_328x428', 328, 428, true); // Product Thumbnail
add_image_size( 'coro_40x40', 40, 40, true); // Testimonials Author Image
add_image_size( 'coro_610x710', 610, 710, true); // Product Carousel Images
add_image_size( 'coro_120x80', 120, 80, true); // Product Category Style 02 Thumbnail
add_image_size( 'coro_560x328', 560, 328, true); // Blog Thumbnails

// Elementor is anchor external target
function coro_is_external($settings_key) {
    if(isset($settings_key['is_external'])) {
        echo $settings_key['is_external'] == true ? 'target="_blank"' : '';
    }
}

// Check if the url is external or nofollow
function coro_is_exno($settings_key) {
    echo $settings_key['is_external'] == true ? 'target="_blank"' : '';
    echo $settings_key['nofollow'] == true ? 'rel="nofollow"' : '';
}


function coro_icon_array($k, $replace = 'icon', $separator = '-') {
    $v = array();
    foreach ($k as $kv) {
        $kv = str_replace($separator, ' ', $kv);
        $kv = str_replace($replace, '', $kv);
        $v[] = array_push($v, ucwords($kv));
    }
    foreach($v as $key => $value) if($key&1) unset($v[$key]);
    return array_combine($k, $v);
}


// Social Share
function coro_social_share() { ?>
    <div class="social_icon">
        <?php esc_html_e( 'share:', 'coro-core') ?>
        <ul class="list-unstyled">
            <li><a href="https://facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><i class="social_facebook"></i></a></li>
            <li><a href="https://twitter.com/intent/tweet?text=<?php the_permalink(); ?>"><i class="social_twitter"></i></a></li>
            <li><a href="https://www.pinterest.com/pin/create/button/?url=<?php the_permalink() ?>"><i class="social_pinterest"></i></a></li>
            <li><a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink() ?>"><i class="social_linkedin"></i></a></li>
        </ul>
    </div>
    <?php
}

function coro_enter_title( $input ) {
    global $post_type;
    if( is_admin() && 'Enter title here' == $input && 'team' == $post_type )
        return 'Enter here the team member name';
    return $input;
}
add_filter( 'gettext','coro_enter_title' );

// Category array
function coro_cat_array( $term = 'category' ) {
    $cats = get_terms( array(
        'taxonomy' => $term,
        'hide_empty' => true
    ));
    $cat_array = array();
    $cat_array[] = '';
    foreach ($cats as $cat) {
        $cat_array[$cat->slug] = $cat->name;
    }
    return $cat_array;
}


// Get the first category name
function coro_first_category($term = 'category') {
    $cats = get_the_terms(get_the_ID(), $term);
    $cat  = is_array($cats) ? $cats[0]->name : '';
    echo esc_html($cat);
}

// Get the first category link
function coro_first_category_link($term='category') {
    $cats = get_the_terms(get_the_ID(), $term);
    $cat  = is_array($cats) ? get_category_link($cats[0]->term_id) : '';
    echo esc_url($cat);
}

// Get blog category list
function coro_taxonomy_terms($term = 'category') {
   $cats = get_the_terms( get_the_ID(), $term);
   $cats_count = count($cats);
   $i = 1;
    foreach ( $cats as $cat ) {
        $separator = ($i == $cats_count) ? '' : ', ';
        echo '<a href="'. get_term_link( $cat->term_id ) .'" class="categori_tag">' .$cat->name. '</a>'.$separator;
        ++$i;
    }
}


// Limit latter
function coro_limit_latter_recent_post ($string, $limit_length, $suffix = '...') {
    if (strlen($string) > $limit_length) {
        echo strip_shortcodes(substr($string, 0, $limit_length) . $suffix);
    }
    else {
        echo strip_shortcodes(esc_html($string));
    }
}


function coro_product_gallery(){
    global $product;
    $gallery_ids = $product->get_gallery_image_ids();
    foreach ( $gallery_ids as $gallery_id ) {
       ?>
        <a href="<?php the_permalink() ?>">
            <?php echo wp_get_attachment_image( $gallery_id, 'full', array( 'class' => 'primary_thumb' ) ); ?>
        </a>
        <?php
    }
}


// Ajax mini cart update
add_filter( 'woocommerce_add_to_cart_fragments', 'header_add_to_cart_fragment', 30, 1 );
function header_add_to_cart_fragment( $fragments ) {
	global $woocommerce;
	ob_start(); ?>
    <div class="cart-btn nav-link"><i class="ti-bag"></i><span class="num"><?php echo $woocommerce->cart->cart_contents_count; ?></span></div>
	<?php
	$fragments['div.cart-btn.nav-link'] = ob_get_clean();

	return $fragments;
}


add_filter( 'woocommerce_add_to_cart_fragments', function($fragments) {
	ob_start(); ?>

    <div class="minicart_panel_wrap">
		<?php woocommerce_mini_cart(); ?>
    </div>
	<?php $fragments['div.minicart_panel_wrap'] = ob_get_clean();

	return $fragments;

} );