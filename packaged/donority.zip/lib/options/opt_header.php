<?php
// Header Section
Redux::set_section( 'donority_opt', array(
    'title'            => esc_html__( 'Header', 'donority' ),
    'id'               => 'header_settings_opt',
    'customizer_width' => '400px',
    'icon'             => 'dashicons dashicons-arrow-up-alt2',
));


// Logo
Redux::set_section( 'donority_opt', array(
    'title'            => esc_html__( 'Logo', 'donority' ),
    'id'               => 'upload_logo_opt',
    'subsection'       => true,
    'icon'             => '',
    'fields'           => array(
        array(
            'title'     => esc_html__( 'Upload logo', 'donority' ),
            'subtitle'  => esc_html__( 'Upload here a image file for your logo', 'donority' ),
            'id'        => 'logo',
            'type'      => 'media',
            'default'   => array(
                'url'   => DONORITY_IMAGES.'/default_logo/logo.png'
            )
        ),

        array(
            'title'     => esc_html__( 'Sticky header logo', 'donority' ),
            'id'        => 'sticky_logo',
            'type'      => 'media',
            'default'   => array(
                'url'   => DONORITY_IMAGES.'/default_logo/logo_sticky.png'
            )
        ),

        array(
            'title'     => esc_html__( 'Retina Logo', 'donority' ),
            'subtitle'  => esc_html__( 'The retina logo should be double (2x) of your original logo', 'donority' ),
            'id'        => 'retina_logo',
            'type'      => 'media',
        ),

        array(
            'title'     => esc_html__( 'Retina Sticky Logo', 'donority' ),
            'subtitle'  => esc_html__( 'The retina logo should be double (2x) of your original logo', 'donority' ),
            'id'        => 'retina_sticky_logo',
            'type'      => 'media',
        ),

        array(
            'title'     => esc_html__( 'Logo dimensions', 'donority' ),
            'subtitle'  => esc_html__( 'Set a custom height width for your upload logo.', 'donority' ),
            'id'        => 'logo_dimensions',
            'type'      => 'dimensions',
            'units'     => array( 'em','px','%' ),
            'output'    => '.logo_info .navbar-brand img'
        ),

        array(
            'title'     => esc_html__( 'Padding', 'donority' ),
            'subtitle'  => esc_html__( 'Padding around the logo. Input the padding as clockwise (Top Right Bottom Left)', 'donority' ),
            'id'        => 'logo_padding',
            'type'      => 'spacing',
            'output'    => array( '.logo_info .navbar-brand img' ),
            'mode'      => 'padding',
            'units'     => array( 'em', 'px', '%' ),      // You can specify a unit value. Possible: px, em, %
            'units_extended' => 'true',
        ),
    )
) );


/**
 * Menu Settings
 */
Redux::set_section( 'donority_opt', array(
    'title'            => esc_html__( 'Header Styling', 'donority' ),
    'id'               => 'header_styling_opt',
    'icon'             => '',
    'subsection'       => true,
    'fields'           => array(
         array(
            'id'       => 'search_icon_toggle',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Search Icon', 'donority'),
            'options' => array(
                'yes' => esc_html__('Yes', 'donority'), 
                'no' => esc_html__('No', 'donority'), 
             ), 
            'default' => 'yes'
        )

    )
));