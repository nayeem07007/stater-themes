<?php
/**
 * Enqueue site scripts and styles
 */
function donority_scripts() {

    /**
     * Enqueueing Stylesheets
     */
	wp_enqueue_style( 'donority-fonts', donority_fonts_url() );
	wp_enqueue_style( 'mediaelementplayer', DONORITY_VEND . '/media-player/mediaelementplayer.css' );
	wp_enqueue_style( 'fontawesome', DONORITY_VEND . '/font-awesome/all.min.css' );
	wp_enqueue_style( 'donority-icomoon', DONORITY_VEND . '/icomoon/icomoon.css', array(), DONORITY_VERSION );
	wp_enqueue_style( 'donority-main-style', get_theme_file_uri('/assets/css/style.css'), array(), DONORITY_VERSION );

	wp_enqueue_style( 'donority-root', get_stylesheet_uri(), array(), DONORITY_VERSION );
    wp_style_add_data( 'donority-root', 'rtl', 'replace' );


    /**
     * Enqueueing Scripts
     */
	wp_enqueue_script( 'mediaelement-and-player', DONORITY_VEND. '/media-player/mediaelement-and-player.min.js', array('jquery'), '4.2.6', true );
	wp_enqueue_script( 'parallaxie', DONORITY_VEND. '/parallax/parallaxie.js', array('jquery'), '0.5', true );
	wp_enqueue_script( 'donority-main-js', DONORITY_JS . '/main.js', array('jquery'), DONORITY_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'donority_scripts' );