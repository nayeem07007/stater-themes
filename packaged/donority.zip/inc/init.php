<?php 


require DONORITY_THEMEROOT_DIR . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require DONORITY_THEMEROOT_DIR . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require DONORITY_THEMEROOT_DIR . '/inc/template-functions.php';
/**
 * Donority helper 
 */
require DONORITY_THEMEROOT_DIR . '/inc/helper.php';

/**
 * Donority comment area
*/
require DONORITY_THEMEROOT_DIR.'/inc/classes/comment_walker.php';
/**
 * Donority nav walker
*/
require DONORITY_THEMEROOT_DIR.'/inc/classes/main-nav-walker.php';
/**
 * Customizer additions.
 */
require DONORITY_THEMEROOT_DIR . '/inc/customizer.php';

/**
 * Donority Enqueue 
 */

require DONORITY_THEMEROOT_DIR . '/inc/static_enqueue.php';

/**
 * Donority Admin Enqueue 
 */

require DONORITY_THEMEROOT_DIR . '/inc/admin_enqueue.php';


/**
 * Donority breadcrumbs
 */

require DONORITY_THEMEROOT_DIR . '/inc/breadcrumbs.php';

/**
 * Donority Tgm
 */
require DONORITY_THEMEROOT_DIR . '/inc/plugin_activation.php';


/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require DONORITY_THEMEROOT_DIR . '/inc/jetpack.php';
}
