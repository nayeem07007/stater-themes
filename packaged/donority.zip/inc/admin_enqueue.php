<?php 
/**
 * Donority admin Enqueue 
 */

add_action( 'admin_enqueue_scripts', 'donority_admin_enqueues');

function donority_admin_enqueues() {
  
    if(function_exists('get_current_screen')){
    
        $screen = get_current_screen(); 
        
        if ( $screen->base == 'toplevel_page_donority_options' ) {
            wp_enqueue_style( 'donority-redux-style', DONORITY_CSS.'/redux-style.css' );
        }
    }
    
}
