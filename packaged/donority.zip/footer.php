<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package donority
 */
global $post;

$footer_id = '';
if ( isset( $post->ID) ) {
    $footer_id = donority_header_footer_builder_id('droit_footer', $post->ID);
}

if ( $footer_id != '' && class_exists( '\Elementor\Plugin' ) ) {
    echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $footer_id );
} else {
    $footer_text = donority_opt('footer_copyright_txt', 'Copyright &copy; 2021 <a href="#">DroitThemes</a> | All rights reserved');
    ?>
    <footer id="colophon" class="site-footer text-center">
        <div class="site-info container">
            <?php echo donority_kses($footer_text); ?>
        </div><!-- .site-info -->
    </footer><!-- #colophon -->
    <?php
}

?>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
